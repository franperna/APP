<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <link rel="stylesheet" href="en-tete3.css">
  <title>accueil</title>
</head>
<body background="fond.jpg" style="width:100%">
<header>
<div class="container" style="background-color:#404040;color:white;width:100%;position:fixed;">
<h1 style="text-align:center;">On est la pour faire du sport</h1>

<div id="im">
    <a href="logo.php"><img class="imageconnexion" src="julien.png" alt="" /></a>
</div>
</div>
<br>
<div id="co1">
	<a class="boutton" href="Inscription.html"> S'inscrire  </a></li> 
</div>
<div id="co1">
 <a class="boutton" href="Connexion.html"> Se connecter </a></li>
</div>
<div id="menu">
  <ul id="onglets">
   <li class="active"><a href="Accueil.html"> Accueil </a></li>
    	<li><a href="Forums.html"> Rechercher un groupe </a></li>
		<li><a href="Livre_or.html"> Créer un groupe </a></li>
		<li><a href="forum.html"> Forum</a></li>
		<li><a href="recherche.html"> Aide</a></li>
  </ul>
</div>
</header>


<section>
<p> Nouveauté </p>

</section>
<footer>



</footer>
</body>
</html>