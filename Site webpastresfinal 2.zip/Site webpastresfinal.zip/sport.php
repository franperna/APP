<?php
try
	{
		$bdd = new PDO('mysql:host=localhost;dbname=le_site_du_sport;charset=utf8', 'root', 'root');
		$bdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	}
	catch (Exception $e)
	{
			die('Erreur : ' . $e->getMessage());
	}
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <link rel="stylesheet" href="cssbackoffice.css">
  <title>BackOfficeAccueil</title>
</head>

<body>


<nav class="menu" style="width:18%;">
  <header class="container1">
    <br>
    <a href="logo1.php"><img class="imageconnexion" src="logo3.jpg" alt="" /></a>
    <div style="margin-left: 25%; text-align: right;">
      <br><br>
    <a class="boutton" href="admin.php">&nbsp;Accueil&nbsp;</a><br><br>
    <a class="boutton" href="sport.php">&nbsp;&nbsp;Sports&nbsp;&nbsp;</a><br><br>
    <a class="boutton" href="groupes.php">&nbsp;Groupes</a><br><br>
    <a class="boutton" href="forum.php">&nbsp;&nbsp;Forum&nbsp;&nbsp;</a><br><br>
    <a class="boutton" href="faq.php">&nbsp;&nbsp;FAQ&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a><br><br>
	
  </div>
</nav>


<div style="margin-left:18%">
<header class="container" style="background-color:rgb(128, 75, 144);color:white;width:95%;position:fixed;z-index: 3;">


  <h1 style="text-align:center;">Back-Office</h1>
  <h3 style="text-align:center;">SPORT</h3>
</header>
</br>
</br>

<div id="form1">

<form method="post" >

Ajouter une catégorie:
					<input type="text" name="categorie2" id="categorie2" /> 
					
					<input type="submit" name="ajouter" value="valider"/>


					<label for="sport"> Ajouter un sport:</label>
					<input type="text" name="sport" id="sport" />

					</br>
					Sélectionner une catégorie:
					<select id="selectbox" name="categorie" size=1>
               <option value="#" name="categorie"> </option>
               <?php
$req = $bdd->query('SELECT id,type_sport FROM categorie ORDER BY id');
while ($donnees = $req->fetch())
{ 
?>
               <option name="categorie" value="<?php echo htmlspecialchars($donnees['id']); ?>" method="post"><?php echo htmlspecialchars($donnees['type_sport']); ?> </option>
               <?php
} // Fin de la boucle des billets
$req->closeCursor();
?>
       </select>


<input type="submit" name="choisir" value="valider"/>

</form>
<?php

if(isset($_POST['choisir']))
{
$req = $bdd->prepare('INSERT INTO sport (type,id_categorie) VALUES(?,?)');
$req->execute(array(
	  $_POST['sport'],
      $_POST['categorie']
	  ));


}
if(isset($_POST['ajouter']))
{
$req = $bdd->prepare('INSERT INTO categorie (type_sport) VALUES(?)');
$req->execute(array(
	  $_POST['categorie2']
	  ));


}



?>

</div>
</body>
</html>