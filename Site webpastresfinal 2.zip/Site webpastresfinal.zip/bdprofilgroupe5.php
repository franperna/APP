<?php
session_start();
try
{
	$bdd = new PDO('mysql:host=localhost;dbname=le_site_du_sport;charset=utf8', 'root', 'root');
}
catch (Exception $e)
{
        die('Erreur : ' . $e->getMessage());
}


htmlentities($nom = $_POST['nom']);
htmlentities($prenom = $_POST['prenom']);
$req = $bdd->query('SELECT id,nom,prenom FROM utilisateur WHERE prenom= "'.$prenom.'" AND nom= "'.$nom.'"  ');
while ($donnees = $req->fetch())
{ 
$aa=htmlspecialchars($donnees['id']);
}
$req->closeCursor();
$req = $bdd->prepare('INSERT INTO Invitation(id_invite,id_demande) VALUES(?,?)');
$req->execute(array(
      $aa,
      $_GET['nom']
	  ));
header('Location: profilgroupe.php?nom='.$_GET['nom']);


?>