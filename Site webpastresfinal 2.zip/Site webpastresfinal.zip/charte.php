<?php session_start();?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <link rel="stylesheet" href="en-tete3.css">
  <title>accueil</title>
</head>
<body background="fond.jpg" style="width:100%">
<header>
<div class="container" style="background-color:#404040;color:white;width:100%;position:fixed;z-index:3;">
<h2 style="text-align:center;"> Qui seront vos prochains compagnons de sport?</h2>

<div id="im">
    <img class="imageconnexion" src="logobis.jpg" style="height:125px; width:400px;" alt="" />
</div>
</div>
<br>

<?php if(isset($_SESSION['id'])){
$req = $bdd->query('SELECT id,prenom,photo FROM utilisateur WHERE id="'.$_SESSION['id'].'" ');
echo '<div id="co1">';
while ($donnees = $req->fetch())
{ echo '<a href="profil.php">'.$donnees['prenom'].'</a>';
  echo '<a href="profil.php"> <img src="IMG/avatar/'.$donnees['photo'].'" alt="avatar" width="40" /></a>';
  echo '<a class="boutton" href="deconnexion.php"> Se déconnecter  </a></li>';
} else{ ?>
<div id="co1">

 <a class="boutton" href="inscription.php"> Inscription   </a></li> 
 <a class="boutton" href="connexion.php"> Se connecter </a></li>
</div>
<?php }?>
<div id="menu">
  <ul id="onglets">
   <li class="active"><a href="Home.php"> Accueil </a></li>
      <li><a href="Group.php"> Rechercher un groupe </a></li>
    <li><a href="creergroupe.php"> Créer un groupe </a></li>
    <li><a href="Forums.php"> Forum</a></li>
    <li><a href="Help.php"> Aide</a></li>
  </ul>
</div>
</header>
<section>
<?php echo '
Charte de modération de lesitedusport.com

Règles à respecter dans le cadre des contributions de lecteurs et commentaires d\'articles.

L’internaute qui souhaite réagir en postant une contribution ou un commentaire s’engage à accepter les règles suivantes : 

Cet espace d’échange est un lieu où le respect d\'autrui est primordial. 
Les messages agressifs, moqueries gratuites, vulgarités, seront donc supprimés.

Toute allusion sexiste, homophobe ou raciste sera effacée. 
Sont considérés comme illicites (liste non exhaustive) :
·    la pédophilie,
·    l\'incitation à la haine raciale et à la discrimination,
·    la négation des crimes contre l\'humanité,
·    l\'appel au meurtre,
·    le proxénétisme,
·    l\'insulte (injures, propos grossiers, agressifs, irrévérencieux…),
·    la diffamation (imputation d\'un fait portant atteinte à l\'honneur ou à la considération de la personne physique ou morale, ou du corps auquel le fait est imputé),
·    l\'incitation à la consommation de drogues, alcool, tabac.

Les messages contenant les éléments suivants seront également supprimés :
·    Les messages publicitaires,
·    Les petites annonces,
·    Les messages contenant des coordonnées téléphoniques, une adresse e-mail ou une adresse postale,
·    Les liens vers des sites externes.

L’internaute est responsable des contenus de ses messages. 
Les internautes peuvent signaler des messages qu’ils estiment non conformes à cette Charte de modération.

En cas de non respect de la Charte, les contenus postés seront supprimés. 
Le site n’a pas l’obligation de prévenir l’auteur du message, ni l’obligation de motiver sa décision de suppression.
Les messages laissés par les internautes et répondant à cette charte seront publiés sur le site et ne pourront être supprimés.
Ils ne peuvent être considérés comme une œuvre et ne seront donc pas soumis aux droits d\'auteur.';
?>
</section>
<footer>
</br>
<a href="https://www.facebook.com/"> <img  src="0facebook-miniature.jpg" alt="Photo de facebook" title="Facebook"/> </a>
<a href="https://www.twitter.com/"> <img src="Twitter_logo.png" alt="Photo de twitter" title="Twitter"/> </a>
<p>qui sommes-nous ? mention légale  condition d'utilisation</p>

</footer>
</html>