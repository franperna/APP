<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <link rel="stylesheet" href="en-tete3.css">
  <title>accueil</title>
</head>
<body background="fond.jpg" style="width:100%">
<header>
<div class="container" style="background-color:#404040;color:white;width:100%;position:fixed;z-index:3;">
<h2 style="text-align:center;"> Qui seront vos prochains compagnons de sport?</h2>

<div id="im">
    <img class="imageconnexion" src="julien.png" style="height:120px; width:300px;" alt="" />
</div>
</div>
<br>

<div id="co1">
	<a class="boutton" href="Inscription.html"> S'inscrire  </a></li> 
 <a class="boutton" href="Connexion.html"> Se connecter </a></li>
</div>
<div id="menu">
  <ul id="onglets">
   <li class="active"><a href="Accueil.html"> Accueil </a></li>
      <li><a href="Forums.html"> Rechercher un groupe </a></li>
    <li><a href="Livre_or.html"> Créer un groupe </a></li>
    <li><a href="forum.html"> Forum</a></li>
    <li><a href="recherche.html"> Aide</a></li>
  </ul>
</div>
</header>


<section>
<p> Nouveauté </p>

</section>
<footer>
</br>
<a href="https://www.facebook.com/"> <img  src="0facebook-miniature.jpg" alt="Photo de facebook" title="Facebook"/> </a>
<a href="https://www.twitter.com/"> <img src="Twitter_logo.png" alt="Photo de twitter" title="Twitter"/> </a>
<p>qui sommes-nous ? mention légale  condition d'utilisation</p>

</footer>
 
</body>