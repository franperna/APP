<?php 
session_start();
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <link rel="stylesheet" href="en-tete3.css">
  <title>accueil</title>
</head>
<body background="fond.jpg" style="width:100%">
<header>
<div class="container" style="background-color:#404040;color:white;width:100%;position:fixed;z-index:3;">
<h2 style="text-align:center;"> Qui seront vos prochains compagnons de sport?</h2>

<div id="im">
    <img class="imageconnexion" src="logobis.jpg" style="height:125px; width:400px;" alt="" />
</div>
</div>
<br>

<?php if(isset($_SESSION['id'])){
$req = $bdd->query('SELECT id,prenom,photo FROM utilisateur WHERE id="'.$_SESSION['id'].'" ');
echo '<div id="co1">';
while ($donnees = $req->fetch())
{ echo '<a href="profil.php">'.$donnees['prenom'].'</a>';
  echo '<a href="profil.php"> <img src="IMG/avatar/'.$donnees['photo'].'" alt="avatar" width="40" /></a>';
  echo '<a class="boutton" href="deconnexion.php"> Se déconnecter  </a></li>';
}
echo'</div>';
} else{ ?>
<div id="co1">

 <a class="boutton" href="inscription.php"> Inscription   </a></li> 
 <a class="boutton" href="connexion.php"> Se connecter </a></li>
</div>
<?php }?>
<div id="menu">
  <ul id="onglets">
   <li class="active"><a href="Home.php"> Accueil </a></li>
      <li><a href="Group.php"> Rechercher un groupe </a></li>
    <li><a href="creergroupe.php"> Créer un groupe </a></li>
    <li><a href="Forums.php"> Forum</a></li>
    <li><a href="Help.php"> Aide</a></li>
  </ul>
</div>
</header>
<section>
<article style="position:relative; left:25%;
                                 top:15%;
                 width:65%;
    height:75%;
    background-color: #404040;
    overflow:scroll;" >
<?php
echo'10 janvier 2016</br></br>

Avant propos :</br>
Le site du sport est un service de réseau social fourni par la SAS le site du sport, mettant en œuvre toutes les technologies multimédia de l’Internet afin de favoriser les échanges d\'informations et la mise en relation de personnes autour de la thématique des sports et loisirs. Nous vous invitons à prendre connaissance des présentes conditions d\'utilisation (CGU) du site du sport. </br></br>

En vous inscrivant, vous devenez Membre du site du sport et prenez l’engagement de respecter les présentes conditions d\'utilisation. L\'inscription à un ou plusieurs services du site du sport ainsi que l\'utilisation du site suppose l\'acceptation pleine et entière des présentes conditions. Il va de soi que ces règles sont édictées, non pour limiter les libertés de chacun, mais au contraire pour préserver ces libertés et garantir un service Internet responsable et de qualité.</br></br>

Le site du sport se réserve le droit de modifier ces conditions à tout moment sans préavis et sans en informer ses Membres pour les adapter aux évolutions des services qu\'il propose, à de nouvelles réglementations ou bien pour toute autre raison. C\'est au Membre de les vérifier régulièrement et de résilier son compte si elles ne sont plus compatibles avec ses souhaits.</br></br>

Les présentes conditions générales d\'utilisation de www.lesitedusport.com, tout comme l\'ensemble du contenu du site Web, sont soumis à stricte autorisation pour toute utilisation. Sans cette autorisation préalable et écrite, le contrevenant s\'expose aux poursuites prévues par la loi Française.</br></br>

Glossaire :</br></br>

Dans les présentes conditions d\'utilisation, les mots ou expressions ont la signification suivante :</br></br>

« Le site du sport » ou www.lesitedusport.com désignent le service, édités par la société Le site du sport .</br></br>

« Services », « service Le site du sport  » ou « Services Le site du sport  » désignent l\'ensemble des outils mis à la disposition des Membres par le biais du site www.www.lesitedusport.com</br></br>

« Membre » désigne un(e) utilisateur(trice) des services Le site du sport valablement inscrit(e), et qui a donc au préalable accepté les présentes conditions.</br></br>

Les équipements informatiques et les moyens de télécommunications permettant l\'accès aux site sont à la charge exclusive du Membre, de même que les frais de télécommunications générés par leur utilisation. Pour être Membre du site du sport, vous devez être âgé(e) au minimum de 16 ans et remplir l\'ensemble des champs obligatoires figurant dans le formulaire d\'inscription.</br></br>

Le Membre garantit que les données qu\'il communique sont exactes et conformes à la réalité. Il s\'engage à informer Le site du sport sans délai en cas de modification des données qu\'il a communiquées lors de son inscription et le cas échéant à procéder lui-même aux dites modifications au sein de son espace personnel du site Le site du sport.</br></br>

Lorsque les conditions nécessaires à l\'inscription sont remplies, chaque Membre dispose d\'un identifiant (nom d’utilisateur ou login) et d\'un mot de passe. Ces éléments sont strictement personnels et confidentiels et ne devront pas être communiqués ni partagés avec des tiers.</br></br>

Dans le cas où un Membre diffuserait ou utiliserait ces éléments de façon contraire à leur destination, Le site du sport se réserve le droit de résilier le compte du Membre sans préavis.</br></br>

LE MEMBRE SERA SEUL RESPONSABLE DE L\'UTILISATION DE CES ELEMENTS D\'IDENTIFICATION PAR DES TIERS OU DES ACTIONS OU DECLARATIONS FAITES PAR L\'INTERMEDIAIRE DE SON COMPTE PERSONNEL DE MEMBRE, QU\'ELLES SOIENT FRAUDULEUSES OU NON. IL GARANTIT LE SITE DU SPORT CONTRE TOUTE DEMANDE A CE TITRE. PAR AILLEURS, LE SITE DU SPORT NE DISPOSANT PAS DES MOYENS DE VERIFIER L\'IDENTITE DES PERSONNES S\'INSCRIVANT A SES SERVICES, LE SITE DU SPORT N\'EST PAS RESPONSABLE EN CAS D\'USURPATION DE L\'IDENTITE D\'UN MEMBRE.</br></br>

Si le Membre a des raisons de penser qu\'une personne utilise ses éléments d\'identification ou son compte, il devra en informer immédiatement Le site du sport.</br></br>

Dans le cas d\'un conflit avec un ou plusieurs autres Membres, Le site du sport ne sera pas tenu responsable des dommages dans le présent ou le futur, de quelque manière que ce soit, qui seraient le résultat d\'un conflit.</br></br>

Le site du sport se réserve le droit de désactiver les comptes des Membres qui n\'ont pas utilisé le service durant une période supérieure ou égale à 1 an. La date de fin d\'utilisation du service prise en compte pour le calcul de la durée de la période se définit de la manière suivante : la date de la dernière connexion valide aux services Le site du sport.</br></br>

Contenu de vos données personnelles :</br></br>

Le site du sportse réserve le droit de rejeter tout ou partie, dont le texte :</br></br>

utilise un vocabulaire et/ou un pseudo vulgaire ou obscène, constitue une atteinte aux bonnes mœurs, une infraction à la législation en vigueur porte des propos diffamatoires, racistes, homophobes, xénophobes, zoophiles, pédophiles, ou à vocation commerciale, et d’une manière générale tout écrit contraire à l’esprit du site Le site du sport.</br></br>

Il en va de même concernant la publication de visuels; pourront être rejetée les publication : à caractère obscène, constituant une atteinte aux bonnes mœurs, une infraction à la législation en vigueur, de caractère racistes, homophobes, xénophobes, zoophiles, pédophiles, ou à vocation commerciale, montrant les coordonnées de la personne, contraire à l\'esprit du site Le site du sport.</br></br>

Vous reconnaissez que Le site du sport peut visionner le contenu avant et pendant sa diffusion. Vous reconnaissez et acceptez que si Le site du sport protège le contenu, Le site du sport peut être amené à le divulguer pour se conformer aux lois en vigueur ou si de bonne foi, Le site du sport pense qu\'une telle mesure est nécessaire dans le cadre d\'une procédure judiciaire: pour faire respecter les conditions d\'utilisation, pour répondre à des plaintes arguant de la violation des droits de tiers, pour protéger les droits ou les intérêts du site du sport, ses utilisateurs ou le public.</br></br>

Engagement des utilisateurs du site du sport:</br></br>

Une fois inscrit, le Membre bénéficiera d\'un accès aux services disponibles sur Le site du sport.</br></br>

Dans le cadre de l\'utilisation des services, le Membre s\'engage notamment à respecter les règles suivantes :</br></br>

• se conformer aux lois en vigueur et respecter les droits des tiers ;</br></br>

• ne pas utiliser Le site du sport à des fins professionnelles ou commerciales ou idéologiques : prospection, racolage, prostitution, propagande...;</br></br>

• ne poster, n\'indiquer ou ne diffuser sous quelle que forme que ce soit des informations ou contenus non conformes à la réalité ;</br></br>

• ne pas tenir des propos, ni diffuser, sous quelle que forme que ce soit, des contenus contrevenant aux droits d\'autrui ou à caractère diffamatoire, injurieux, obscène, pédophile, homophobe, xénophobe, zoophile, violent ou incitant à la violence ;</br></br>

• ne pas poster, indiquer ni diffuser sous quelle que forme que ce soit des informations ou contenus ayant pour effet de diminuer, de désorganiser, d\'empêcher l\'utilisation normale des Services, d\'interrompre et/ou de ralentir la circulation normale des communications entre les Membres par l\'intermédiaire des Services, tels que des logiciels, virus, bombes logiques, envoi massif de messages ... Le site du sport se réserve le droit de supprimer les messages qui sont envoyés massivement par un Membre afin de préserver une qualité d\'utilisation normale du service auprès des autres Membres ;</br></br>

ATTENTION : TOUTE TENTATIVE CONSISTANT A ENDOMMAGER DELIBEREMENT UN SITE WEB REPRESENTE UNE INFRACTION AU DROIT PENAL ET AU DROIT CIVIL. SI LE CAS VENAIT A SE PRODUIRE, LE SITE DU SPORT DISQUALIFIERAIT LE CONTREVENANT ET SE RESERVERAIT LE DROIT DE LE POURSUIVRE EN DOMMAGES-INTERETS DANS LES LIMITES MAXIMALES PERMISES PAR LA LOI.</br></br>

• ne pas poster, indiquer ni diffuser sous quelque forme que ce soit des informations ou contenus intégrant des liens vers des sites tiers qui auraient un caractère illégal, contraires aux bonnes mœurs et/ou non conformes à l\'objet du site du sport. LE SITE DU SPORT NE PEUT ETRE TENU POUR RESPONSABLE DES FAUSSES DECLARATIONS FAITES PAR UN MEMBRE. IL EST DONC IMPORTANT DE PRENDRE CERTAINES PRECAUTIONS LORS DE RENCONTRES AVEC UN AUTRE.</br></br>

LE SITE DU SPORT SE DEGAGE DE TOUTE RESPONSABILITE LORS DE RENCONTRES ENTRE SES MEMBRES, SUR LE SITE OU A L\'EXTERIEUR DU SITE.</br></br>

Le site du sport rappelle à ses Membres qu\'il leur est interdit d\'indiquer ou de divulguer toute information personnelle (nom de famille, adresse postale et/ou électronique, téléphone, etc.) permettant d’identifier un Membre tiers du site du sport sur le site. Le site du sport ne peut être tenu pour responsable des contenus diffusés par un Membre susceptibles de contrevenir aux droits d\'un ou plusieurs autres Membres ou des tiers.</br></br>

Vie privée et protection des données du Membre :</br></br>

Le site du sport respecte les normes les plus strictes de protection de la vie privée et des données personnelles et a fait l\'objet d\'une déclaration auprès de la Commission Nationale de l\'Informatique et des Libertés (CNIL) sous le numéro 1271879.</br></br>

Certaines informations, indications ou contenus, photographies ou vidéos, que les Membres peuvent fournir à titre facultatif sont susceptibles, sous la responsabilité du Membre concerné, de révéler l\'origine ethnique du Membre, sa nationalité et/ou ses préférences relationnelles. En fournissant de telles informations, toutes facultatives, le Membre concerné consent dès lors expressément au traitement de ces données dites " personnelles " par Le site du sport.</br></br>

Les droits et garanties des Membres du site du sport respectent notamment la loi "informatique et libertés" n° 78-17 du 6 janvier 1978 et la loi sur la "confiance dans l\'économie numérique " n° 2004-575 du 21 juin 2004 (article L. 33-4-1 modifié du code des postes et télécommunications et article L. 121-20-5 nouveau du code de la consommation).</br></br>

Pour davantage d\'information, n\'hésitez pas à nous contacter.</br></br>

Tarifs :</br></br>

L\'inscription ausite du sport est gratuite. Tous les contenus et services du site du sport resteront gratuits jusqu\'à nouvel ordre. L\'opérateur se réserve cependant à tout moment le droit de rendre payants certains services précis, tels que par exemple l\'envoi de SMS, ou de s:\'assurer des revenus par le biais de publicité sur la plateforme. Le membre est libre de résilier son inscription à tout moment si les nouveaux termes du contrat ne lui convenaient pas.</br></br>

Propriété intellectuelle :</br></br>

Droits d’auteur et droits afférents
L’ensemble des éléments constituants www.lesitedusport.com, à savoir les textes, les marques, les logos, les graphismes, les animations, les photographies, les vidéos, les bases de données, les créations et œuvres diverses, ainsi que le site lui-même, relève des législations françaises et internationales sur les droits d’auteurs et les droits voisins du droit d’auteur.</br></br>

Ces éléments sont la propriété intellectuelle et exclusive de la société Le site du sport, hormis les éléments réalisés par les prestataires extérieurs à www.lesitedusportcom n’ayant pas cédé leurs droits d’auteur.</br></br>

Toute représentation ou reproduction intégrale ou partielle, sans l’autorisation expresse de la société Le site du sport est interdite, sous peine de poursuites judiciaires. Il en est de même pour la traduction, l’adaptation ou la transformation, l’arrangement ou la reproduction par une technique ou un procédé quelconque.</br></br>

Droit du producteur de la base de données
La société Le site du sport est le producteur de la base de données constituée par le site Le site du sport. Toute extraction ou utilisation du contenu de la base non expressément autorisée peut engager la responsabilité civile et/ou pénale de son auteur. La société Le site du sport se réserve la possibilité d’exercer toutes voies de droit à l’encontre des personnes qui n’auraient pas respecté cette interdiction.</br></br>

Droit de marque
Les dénominations et les logotypes sont des marques déposées, propriétés de la société Le site du sport. Toute utilisation non expressément autorisée peut engager la responsabilité civile et/ou pénale de son auteur. La société Le site du sport se réserve la possibilité d’exercer toutes voies de droit à l’encontre des personnes qui porteraient atteinte à ses droits.</br></br>

Droits d’utilisation
Les droits d\'utilisation concédés par Le site du sport au Membre sont strictement limités à l\'accès, au téléchargement, à l\'impression, à la reproduction sur tous supports et à l\'utilisation de ces documents pour un usage privé et personnel dans le cadre et pour la durée de l\'adhésion au site du sport. Toute autre utilisation par le Membre est interdite sans l\'autorisation du site du sport.</br></br>

Le Membre s\'interdit notamment de modifier, copier, reproduire, télécharger, diffuser, transmettre, exploiter commercialement et/ou distribuer de quelque façon que ce soit les services, les pages du site Le site du sport, ou les codes informatiques des éléments composant les services et le site Le site du sport.</br></br>

Résiliation :</br></br>

Chaque Membre peut résilier son inscription au site du sport à tout moment et sans motif.</br></br>

En cas de manquement par le Membre aux présentes conditions d\'utilisation, Le site du sport se réserve le droit de suspendre ou de résilier le compte du Membre sans préavis et/ou d\'engager des poursuites à son encontre.</br></br>

Cette résiliation interviendra de plein droit et sans préjudice de tous les dommages et intérêts qui pourraient être réclamés par Le site du sport au Membre ou à ses ayants droits et représentants légaux en réparation du préjudice subi du fait de tels manquements.</br></br>

Le Membre sera informé par courrier électronique de la résiliation ou de la confirmation de la résiliation de son compte. Les données relatives au Membre seront détruites à sa demande ou à l\'expiration du délai légal à compter de la résiliation du compte du Membre.</br></br>

Responsabilité et garantie :</br></br>

Informations et contenus fournis par les Membres
Les informations fournies par un Membre au site du sport doivent être exactes et conformes à la réalité. Les conséquences de leur divulgation sur sa vie et/ou celle des autres Membres sont de la responsabilité exclusive du Membre concerné. Le Membre renonce à tout recours à l\'encontre du site du sport, notamment sur le fondement de l\'atteinte éventuelle à son droit à l\'image, à son honneur, à sa réputation, à l\'intimité de sa vie privée, résultant de la diffusion ou de la divulgation d\'informations le concernant dans les conditions prévues par les présentes.</br></br>

Dans le cas où la responsabilité du site du sport serait recherchée à raison d\'un manquement par un Membre aux obligations qui lui incombent aux termes de la loi ou de ces conditions d\'utilisation, ce dernier s\'engage à garantir Le site du sport contre toute condamnation prononcée à son encontre, cette garantie couvrant tant les amendes et indemnités qui seraient éventuellement versées, que les honoraires d\'avocat et frais de justice qui pourraient être mis à sa charge.</br></br>

Fonctionnement du site Le site du sport et des services
Le Membre doit posséder un équipement des logiciels et des paramétrages nécessaires au bon fonctionnement du site du sport : Navigateur IE7, Firefox ou équivalent, ...
Le site du sport ne garantit pas que les services seront utilisables si l\'abonné utilise un utilitaire de « pop-ups killer », dans ce cas, Cette fonction devra être désactivée préalablement à l\'utilisation du service Le site du sport.</br></br>

En outre, le Membre doit disposer des compétences, des matériels et des logiciels requis pour l\'utilisation d\'Internet, ou le cas échéant, de services Internet, téléphoniques et reconnaît que les caractéristiques et les contraintes d\'Internet ne permettent pas de garantir la sécurité, la disponibilité et l\'intégrité des transmissions de données sur Internet.</br></br>

Dans ces conditions, Le site du sport ne garantit pas que les services fonctionneront sans interruption ni erreur de fonctionnement. En particulier, leur exploitation pourra être momentanément interrompue pour cause de maintenance, de mises à jour ou d\'améliorations techniques, ou pour en faire évoluer le contenu et/ou leur présentation. Dans la mesure du possible, Le site du sportinformera ses Membres préalablement à une opération de maintenance ou de mise à jour.</br></br>

Le Membre renonce à rechercher la responsabilité du site du sport au titre du fonctionnement et de l\'exploitation des Services.</br></br>

De même, Le site du sport ne saurait également être tenue responsable d\'un non fonctionnement, d\'une impossibilité d\'accès, ou de mauvaises conditions d\'utilisation du site Le site du sport imputables à un équipement non adapté, à des dysfonctionnements internes au fournisseur d\'accès du Membre, à l\'encombrement du réseau Internet, et pour toutes autres raisons extérieures au site du sport.</br></br>

Liens
Le site le site du sport peut inclure des liens hypertextes vers d\'autres sites Web extérieurs ou vers d\'autres sources Internet. Dans la mesure où Cleec ne peut contrôler ces sites et ces sources externes, il ne peut être tenu pour responsable de la mise à disposition de ces sites et sources externes, et ne peut supporter aucune responsabilité quant à leur contenu, publicités, produits, services ou tout autre élément disponible sur ou à partir de ces sites ou sources externes. Toute difficulté relative à un lien doit être soumise à l\'administrateur ou au webmaster du site concerné. Il est rappelé que la consultation et/ou l\'utilisation de ces sites et sources externes sont régies par leurs propres conditions d\'utilisation. Nous vous encourageons fortement à vérifier les politiques de sécurité et de confidentialité de ces sites avant toute transaction avec eux.</br></br>

Enfin, si dans le cadre d\'une recherche conduite sur le site le site du sport, le résultat de celle-ci amenait le Membre à pointer sur des sites, des pages ou des forums dont le titre et/ou les contenus constituent une violation du droit français, le Membre est invité à interrompre sa consultation du site concerné au risque de voir sa responsabilité engagée, celle du site du sport étant exclue.</br></br>

Alertes :</br></br>

Le site du sport s\'efforce de veiller au respect des principes précédemment énoncés. Eu égard à l\'ampleur des échanges opérés sur le site, le risque de leur violation ne peut être écarté. Si vous étiez témoin du non respect des engagements visés ci-dessus, merci d\'en informer Cleec (contact(@)lesitedusport.com) qui agira dans le respect de votre anonymat.</br></br>

Limitation de responsabilité :</br></br>

La responsabilité globale du site du sport est limitée au cadre de la prestation faisant l\'objet d\'un manquement.</br></br>

Convention entre le membre et Le site du sport :</br></br>

Ces conditions d\'utilisation, ainsi que les pages du site le site du sport auxquelles il est fait référence dans les présentes, constituent un contrat régissant les relations entre le Membre et Le site du sport.</br></br>

Modifications du site du sport ou des conditions générales d\'utilisation : Le site du sport se réserve le droit de modifier ou de faire évoluer à tout moment les pages du site le site du sport ou les conditions d\'utilisation qui leur sont applicables. Ces modifications entreront en vigueur dès leur mise en ligne sur le site.</br></br>

Les Membres sont donc invités à consulter la version constamment en ligne sur le site. La présence du Membre sur le site implique sa pleine acceptation de toute révision ou modification.</br></br>

Droit applicable - attribution de juridiction :</br></br>

Ces conditions d\'utilisation sont régies, interprétées et appliquées conformément au droit français. Les tribunaux de Bobigny seront seuls compétents pour connaître de tout litige relatif aux présentes, y compris, sans que cette énumération soit limitative, leur validité, leur interprétation, leur exécution et/ou leur résiliation et ses conséquences.</br></br>

Editeur du site Le site du sport :</br></br>

L’éditeur du site www.lesitedusport.com est la SAS Le site du sport au capital de 41 333 €, ayant son siège social au 2 rue des blés, 93200 St Denis, immatriculée au Registre du Commerce et des Sociétés de Bobigny sous le numéro 492 308 127.</br></br>

Le directeur de la publication du site est Monsieur Pierre CHAVANON.</br></br>

Le site www.lesitedusport.com est hébergé sur les serveurs de la société Ikoula (http://www.ikoula.com) dont le siège social est situé 175-177 rue d\'Aguesseau 92100 Boulogne Billancourt et immatriculée sous le numéro 417 680 618.</br></br>
Ces serveurs sont gérés par LMC France, SARL au capital de 11 550 Euros, 2, rue des blés, 93210 La Plaine Saint-Denis immatriculée sous le numéro 428 868 749.Pour toute question relative à votre abonnement ou d’ordre général, vous pouvez joindre la société Le site du sport en envoyant un email à l’adresse contact(@)lesitedusport.com.';
?>
</article>
</section>
<footer>
</br>
<a href="https://www.facebook.com/"> <img  src="0facebook-miniature.jpg" alt="Photo de facebook" title="Facebook"/> </a>
<a href="https://www.twitter.com/"> <img src="Twitter_logo.png" alt="Photo de twitter" title="Twitter"/> </a>
<p> Qui sommes-nous ? &nbsp;&nbsp;&nbsp; Mention légale&nbsp;&nbsp;&nbsp;  Conditions générales d'utilisation&nbsp;&nbsp;&nbsp; Charte</p>

</footer>
</html>


