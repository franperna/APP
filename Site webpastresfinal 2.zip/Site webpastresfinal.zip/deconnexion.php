<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <link rel="stylesheet" href="en-tete3.css">
  <title>accueil</title>
</head>
<body background="fond.jpg" style="width:100%">
<header>
<div class="container" style="background-color:#404040;color:white;width:100%;position:fixed;z-index:3;">
<h2 style="text-align:center;"> Qui seront vos prochains compagnons de sport?</h2>

<div id="im">
    <img class="imageconnexion" src="logobis.jpg" style="height:125px; width:400px;" alt="" />
</div>
</div>
<br>

<div id="co1">
    <a class="boutton" href="inscription.php"> Inscription   </a></li> 
 <a class="boutton" href="connexion.php"> Se connecter </a></li>
</div>
<div id="menu">
  <ul id="onglets">
   <li class="active"><a href="Home.php"> Accueil </a></li>
      <li><a href="Group.php"> Rechercher un groupe </a></li>
    <li><a href="creergroupe.php"> Créer un groupe </a></li>
    <li><a href="Forums.php"> Forum</a></li>
    <li><a href="Help.php"> Aide</a></li>
  </ul>
</div>
</header>
<?php
session_start();
// Suppression des variables de session et de la session
$_SESSION = array();
session_destroy();
// Suppression des cookies de connexion automatique
setcookie('login', '');
setcookie('pass_hache', '');
header('Location: Home.php')
?>
<form action="deconnexion.php" method ="post" >
<input type="submit" value="deconnexion"/>
<footer>
</br>
<a href="https://www.facebook.com/"> <img  src="0facebook-miniature.jpg" alt="Photo de facebook" title="Facebook"/> </a>
<a href="https://www.twitter.com/"> <img src="Twitter_logo.png" alt="Photo de twitter" title="Twitter"/> </a>
<p>qui sommes-nous ? mention légale  condition d'utilisation</p>

</footer>
</form>
</body>
</html>