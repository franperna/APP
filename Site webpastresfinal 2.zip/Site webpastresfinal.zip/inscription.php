﻿<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <link rel="stylesheet" href="en-tete3.css">
  <title>accueil</title>
</head>
<body background="fond.jpg" style="width:100%">
<header>
<div class="container" style="background-color:#404040;color:white;width:100%;position:fixed;z-index:3;">
<h2 style="text-align:center;"> Qui seront vos prochains compagnons de sport?</h2>

<div id="im">
    <img class="imageconnexion" src="logobis.jpg" style="height:125px; width:400px;" alt="" />
</div>
</div>
<br>

<div id="co1">
     <a class="boutton" href="inscription.php"> Inscription  </a></li> 
 <a class="boutton" href="connexion.php"> Se connecter </a></li>
</div>
<div id="menu">
  <ul id="onglets">
   <li class="active"><a href="Home.php"> Accueil </a></li>
      <li><a href="Group.php"> Rechercher un groupe </a></li>
    <li><a href="creergroupe.php"> Créer un groupe </a></li>
    <li><a href="Forums.php"> Forum</a></li>
    <li><a href="Help.php"> Aide</a></li>
  </ul>
</div>
</header>
<form method ="post" >
<section>
<article style="position:relative; left:35%;
                                 top:20%;
                 width:30%;
    height:65%;
    background-color: #404040;"> </br>
       <legend><h2>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;<em><u>Inscription</u></em></h2></legend>
     
<p>

<br/>

<label for="firstname">&emsp;&emsp;Nom :</label>
<input type ="text" name="nom" value="<?php if (isset($_POST['nom'])){echo htmlentities($_POST['nom']);} ?>" id="nom" placeholder="Nom.." requered/>
<br/>
<br/>
<label for="lastname">&emsp;&emsp;Prenom :</label>
<input type ="text" name="prenom" value="<?php if (isset($_POST['prenom'])){echo htmlentities($_POST['prenom']);} ?>"id="prenom" placeholder="Prenom.."requered/>
<br/>

</br>

<label for="pass">&emsp;&emsp;Mot de passe :</label>
<input type ="password" name="mot_de_passe" id="mot_de_passe" placeholder="Mot de passe.." required/>
<br/>

<br/>
<label for="passcon">&emsp;&emsp;Confirmation mot de passe :</label></td>
<input type ="password" name="passcon" id="passcon" placeholder="Mot de passe.." required/>


<br/>
<br/>
<label for="email1">&emsp;&emsp;Email :</label>
<input type ="email" name="mail" value="<?php if (isset($_POST['mail'])){echo htmlentities($_POST['mail']);} ?>"id="email1" placeholder="Email.."requered//>
<br/>

<br/>
<label for="email2">&emsp;&emsp;Confirmation Email :</label>
<input type ="email" name="email2"value="<?php if (isset($_POST['email2'])){echo htmlentities($_POST['email2']);} ?>" id="email2" placeholder="Email.." required/>

</br><br/>

&emsp;&emsp; <a href="cgu.php">J'ai lu et accepté les conditions générales</a>&emsp;&emsp; &emsp;&emsp;&emsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="cgu.php">d'utilisation :</a><input type="checkbox" name="Regle"> </br>
 
</br>




&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;<input type="submit" name= Envoyer value="Envoyer"/>

</p>

</form>
<?php
try
{
  $bdd = new PDO('mysql:host=localhost;dbname=le_site_du_sport;charset=utf8', 'root', 'root');
}
catch (Exception $e)
{
        die('Erreur : ' . $e->getMessage());
}
 if(isset($_POST['Envoyer']))
    {
    
      
      // Je recupere les infos, plus securité pour le code.
        htmlentities($mot_de_passe = $_POST['mot_de_passe']);
        htmlentities($passcon = $_POST['passcon']);
        htmlentities($mail = $_POST['mail']);
        htmlentities($email2 = $_POST['email2']);

        htmlentities($prenom = $_POST['prenom']);
        htmlentities($nom = $_POST['nom']);
       
        
        //htmlentities($user_post_office_box = $_POST['user_post_office_box']);
        
        htmlentities($Regle=$_POST['Regle']);
    
    
        // empecher les codes php dans la base
      // Je verifie que TOUT les champs sont remplis.
      if(empty($mot_de_passe)||empty($mail)|| empty($Regle)|| empty($prenom) || empty($nom)  )
      {
                    echo "Vous devez remplir tout les formulaire";
                      //echo '<script type="text/javascript">window.alert("'.$message0.'"); window.location.href="testinscription.php";</script>';
      }
    // filter_var permet de verifier la validité de l'email
      else {
          if (filter_var($mail, FILTER_VALIDATE_EMAIL)) {
               $sql = $bdd->prepare('SELECT mail FROM utilisateur WHERE mail = \'' . $mail . '\';');
              $sql->execute(array('.$mail.' => $_POST['mail']));
              $res = $sql->fetch();
              if ($res) {
                  echo "L'Email que vous avez utilisé existe déjà";
                  //echo '<script type="text/javascript">window.alert("' . $message3 . '"); window.location.href="testinscription.php";</script>';
              } else {
                  if (($mot_de_passe == $passcon) && ($mail == $email2)) {
            $pass_hache = sha1($_POST['mot_de_passe']);
                     // $reponse = $bdd->query("INSERT INTO utilisateur VALUES('$nom', '$prenom','$mail', '$pass_hache'");
           $req = $bdd->prepare('INSERT INTO utilisateur (nom,prenom,mail,mot_de_passe,age,description,civilite) VALUES(?,?,?,?,?,?,?)');
            $req->execute(array(
            $nom,
            $prenom,
            $mail,
            $pass_hache,
            '',
            '',
            ''
            ));
                      //affiche un mot gentil, dans le futur on doit changer pour que ceci apparaisse sur une autre.nom,prenom,mail,mot_de_passe,age,civilite,pseudo
                      echo "Bonjour $prenom votre compte est bien enregistré";
             session_start();
            $_SESSION['id']=$req['id'];
            $_SESSION['nom'] = $_POST['nom'];
            $_SESSION['prenom'] = $_POST['prenom'];
            $_SESSION['mot_de_passe'] = $_POST['mot_de_passe'];
            $_SESSION['mail'] = $_POST['mail'];
            header('location: testinscription.php');
                      //echo '<script type="text/javascript">window.alert("' . $message . '"); window.location.href="testinscription.php";</script>';
                  } else {
                      echo "Les deux mots de passe ou les deux e-mails que vous avez rentrés ne correspondent pas";
                     // echo '<script type="text/javascript">window.alert("' . $message1 . '"); window.location.href="testinscription.php";</script>';
                  }
              }
          } else {
              echo "Votre email n'est pas valide";
             // echo '<script type="text/javascript">window.alert("' . $message2 . '"); //window.location.href="testinscription.php";</script>';
          }
      }
    }
    
?>
</table>
</div>

</article>
</section>

<footer>
</br>
<a href="https://www.facebook.com/"> <img  src="0facebook-miniature.jpg" alt="Photo de facebook" title="Facebook"/> </a>
<a href="https://www.twitter.com/"> <img src="Twitter_logo.png" alt="Photo de twitter" title="Twitter"/> </a>
<p>qui sommes-nous ? mention légale  condition d'utilisation</p>

</footer>
        </div>


</body>
</html>


