
             <!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <link rel="stylesheet" href="en-tete3.css">
  <title>accueil</title>
</head>
<body background="fond.jpg" style="width:100%">
<header>
<div class="container" style="background-color:#404040;color:white;width:100%;position:fixed;z-index:3;">
<h2 style="text-align:center;"> Qui seront vos prochains compagnons de sport?</h2>

<div id="im">
   <img class="imageconnexion" src="logobis.jpg" style="height:125px; width:400px;" alt="" />
</div>
</div>
<br>

<div id="co1">
     <a class="boutton" href="inscription.php"> Inscription  </a></li> 
 <a class="boutton" href="connexion.php"> Se connecter </a></li>
</div>
<div id="menu">
  <ul id="onglets">
   <li class="active"><a href="Home.php"> Accueil </a></li>
      <li><a href="Group.php"> Rechercher un groupe </a></li>
    <li><a href="creergroupe.php"> Créer un groupe </a></li>
    <li><a href="Forums.php"> Forum</a></li>
    <li><a href="Help.php"> Aide</a></li>
  </ul>
</div>
</header>
<section>
<article style="position:relative; left:35%;
                                 top:20%;
                 width:25%;
    height:35%;
    background-color: #404040;">
<form method ="post" >
<div id="news">

       <legend><h2>&emsp;&emsp;&emsp;&emsp;&nbsp;&nbsp;Connexion</h2></legend>
<p>

<label for="nom">&emsp;&emsp;&emsp;&nbsp;&nbsp;Nom :</label>
<input type ="text" name="nom" id="nom" placeholder="Nom.." required/>

</br>

<label for="pass">&emsp;&nbsp;Mot de passe :</label>
<input type ="password" name="mot_de_passe" id="mot_de_passe" placeholder="Mot de passe.." required/>
</br>

</br>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;<input type="submit"  value="Envoyer" name=Envoyer />
</p>
&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Pas encore membre?</br>&emsp;&emsp;&emsp;&emsp;<a href="inscription.php">Inscrivez-vous gratuitement</a></br></br>&emsp;&emsp;&emsp;
&emsp;&emsp;&emsp;&emsp;<a href="connexionadmin.php ">Se connecter en tant qu'administrateur</a></br></br>&emsp;&emsp;&emsp;


<?php 
try
{
	$bdd = new PDO('mysql:host=localhost;dbname=le_site_du_sport;charset=utf8', 'root', 'root');
}
catch (Exception $e)
{
        die('Erreur : ' . $e->getMessage());
}
// Hachage du mot de passe
if(isset($_POST['Envoyer']))

    {
      //print_r($_POST);
htmlentities($mot_de_passe = $_POST['mot_de_passe']);
htmlentities($nom = $_POST['nom']);
// Hachage du mot de passe
$pass_hache = sha1($_POST['mot_de_passe']);
// Vérification des identifiants
$req = $bdd->prepare('SELECT id,nom,prenom,mail,mot_de_passe,age,description,civilite,ville FROM utilisateur WHERE nom = ? AND mot_de_passe = ?');
$req->execute(array(
     $nom,
     $pass_hache));
  
$resultat = $req->fetch();
if (!$resultat)
{
    echo 'Mauvais identifiant ou mot de passe !';
  
}
else
{
    session_start();
  $_SESSION['id'] = $resultat['id'];
  $_SESSION['nom'] = $resultat['nom'];
  $_SESSION['prenom'] =$resultat['prenom'];
  $_SESSION['mot_de_passe'] = $resultat['mot_de_passe'];
  $_SESSION['mail'] = $resultat['mail'];
  $_SESSION['age']=$resultat['age'];
  $_SESSION['description']=$resultat['description'];
  $_SESSION['civilite']=$resultat['civilite'];
  $_SESSION['ville']=$resultat['ville'];

  //print_r($_SESSION);
  
  header('Location: profil.php');
}
}
?>
</div>
</article>
</section>
<footer>
</br>
<a href="https://www.facebook.com/"> <img  src="0facebook-miniature.jpg" alt="Photo de facebook" title="Facebook"/> </a>
<a href="https://www.twitter.com/"> <img src="Twitter_logo.png" alt="Photo de twitter" title="Twitter"/> </a>
<p>qui sommes-nous ? mention légale  condition d'utilisation</p>

</footer>
       
    </body>
</html>