<?php 
try
{
    $bdd = new PDO('mysql:host=localhost;dbname=le_site_du_sport;charset=utf8', 'root', 'root');
}
catch (Exception $e)
{
        die('Erreur : ' . $e->getMessage());
}
session_start();
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <link rel="stylesheet" href="en-tete3.css">
  <title>accueil</title>
</head>
<body background="fond.jpg" style="width:100%">
<header>
<div class="container" style="background-color:#404040;color:white;width:100%;position:fixed;z-index:3;">
<h2 style="text-align:center;"> Qui seront vos prochains compagnons de sport?</h2>

<div id="im">
    <img class="imageconnexion" src="logome.jpg" style="height:115px; width:350px;" alt="" />
</div>
</div>
<br>

<?php if(isset($_SESSION['id'])){
$req = $bdd->query('SELECT id,prenom,photo FROM utilisateur WHERE id="'.$_SESSION['id'].'" ');
echo '<div id="co1">';
while ($donnees = $req->fetch())
{ echo '<div id="prenom"> <a href="profil.php">'.$donnees['prenom'].'</a> </div>';
  echo '<a href="profil.php"> <img src="IMG/avatar/'.$donnees['photo'].'" alt="avatar" width="40" /></a>';
  echo '<a class="boutton" href="deconnexion.php"> Se déconnecter  </a></li>';
}
echo'</div>';
} else{ ?>
<div id="co1">

 <a class="boutton" href="inscription.php">   Inscription  </a></li> 
 <a class="boutton" href="connexion.php">  Se connecter </a></li>
</div>
<?php }?>
<div id="menu">
  <ul id="onglets">
   <li class="active"><a href="Home.php"> Accueil </a></li>
      <li><a href="Group.php"> Rechercher un groupe </a></li>
    <li><a href="creergroupe.php"> Créer un groupe </a></li>
    <li><a href="Forums.php"> Forum</a></li>
    <li><a href="Help.php"> Aide</a></li>
  </ul>
</div>
</header>
     
             <section>

             
                 <article style="position:relative; left:40%;
                                 top:15%;
                 width:400px;
    height:500px;
    background-color: #404040;">
                  <div id="group">
                  <h2></br>&emsp;&emsp;&emsp;&nbsp;&nbsp;<em><u>Rechercher un groupe :</u></em></h2>
             <form method="post" action="rechercheavancee.php">
                  </br><p>
                     &emsp;&emsp;&emsp;&nbsp;&nbsp;&nbsp;Choissisez un groupe:
        <select id="selectbox" name="groupe" size=1 onchange ="javascript:location.href=this.value;">
               <option value="#"> </option>
               <?php
$req = $bdd->query('SELECT id,nomgroupe FROM groupe ORDER BY id');
while ($donnees = $req->fetch())
{
?>
               <option name="sport" value="profilgroupe.php?nom=<?php echo htmlspecialchars($donnees['id']); ?>" method="post"><?php echo htmlspecialchars($donnees['nomgroupe']); ?> </option>
               <?php
} // Fin de la boucle des billets
$req->closeCursor();
?>
<script type="text/javascript">
    window.onload = function(){
        location.href=document.getElementById("selectbox").value;
    }       
</script>
       </select>
       <div id="source" onclick="affiche_contenu8()">
       </br>&emsp;&emsp;&emsp;&nbsp;&nbsp;------------------------------------------------</br> <h2>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&nbsp;&nbsp;OU </h2> &emsp;&emsp;&emsp;&nbsp;&nbsp;------------------------------------------------</br></br>
                 </p>
                 </div>
                 <div id="r" style="display:none;">
                 <p>
                     &emsp;&emsp;&emsp;&nbsp;&nbsp;Choissisez un jour:
                 
                      <select id="selectbox" name="jour" size=1>
               <option name="jour" value="#"> </option>
               <option name="jour" value="Lundi" method="post">Lundi</option>
               <option name="jour" value="Mardi" method="post">Mardi</option>
               <option name="jour" value="Mercredi" method="post">Mercredi</option>
               <option name="jour" value="Jeudi" method="post">Jeudi</option>
               <option name="jour" value="Vendredi" method="post">Vendredi</option>
               <option name="jour" value="Samedi" method="post">Samedi</option>
               <option name="jour" value="Dimanche" method="post">Dimanche</option>
       </select></p>
                   

   <p>
      &emsp;&emsp;&emsp;&nbsp;&nbsp;Choisissez un sport:
          <select id="selectbox" name="sport" size=1>
          <option value="#"> </option>
          <?php
$req = $bdd->query('SELECT id,type FROM sport ORDER BY id');
while ($donnees = $req->fetch())
{
?>
               <option name="sport" value="<?php echo htmlspecialchars($donnees['id']); ?>" method="post"> <?php echo htmlspecialchars($donnees['type']); ?> </option>
             <?php
} // Fin de la boucle des billets
$req->closeCursor();
?>
         </select>      
  </br>
   </p>

   <p>
        <label> &emsp;&emsp;&emsp;&nbsp;&nbsp;Entrez votre ville : </label> 
                     <input type="text" name="ville" id="ville" placeholder="Paris" size="20" maxlength="50" /> </p>
                <p>
   </p></br>
    &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;<input type="submit" value="valider"/>
</form>    </div> 

<script type="text/javascript">
 function affiche_contenu8() {
      var r = document.getElementById('r');
      if(r.style.display != '') {
        r.style.display = '';
      } else {
        r.style.display = 'none';
      }
    }
      </script>                      
                      </div></br></br>
 
                 </article>
</section>
<footer>
</br>
<a href="https://www.facebook.com/"> <img  src="0facebook-miniature.jpg" alt="Photo de facebook" title="Facebook"/> </a>
<a href="https://www.twitter.com/"> <img src="Twitter_logo.png" alt="Photo de twitter" title="Twitter"/> </a>
<p>qui sommes-nous ? mention légale  condition d'utilisation</p>

</footer>
        </div>
    </body>
</html>