<?php
// Connexion à la base de données
try
{
    $bdd = new PDO('mysql:host=localhost;dbname=le_site_du_sport;charset=utf8', 'root', 'root');
}
catch(Exception $e)
{
        die('Erreur : '.$e->getMessage());
}
session_start();
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <link rel="stylesheet" href="en-tete3.css">
  <title>accueil</title>
</head>
<body background="fond.jpg" style="width:100%">
<header>
<div class="container" style="background-color:#404040;color:white;width:100%;position:fixed;z-index:3;">
<h2 style="text-align:center;"> Qui seront vos prochains compagnons de sport?</h2>

<div id="im">
    <img class="imageconnexion" src="logome.jpg" style="height:115px; width:350px;" alt="" />
</div>
</div>
<br>

<?php if(isset($_SESSION['id'])){
$req = $bdd->query('SELECT id,prenom,photo FROM utilisateur WHERE id="'.$_SESSION['id'].'" ');
echo '<div id="co1">';
while ($donnees = $req->fetch())
{ echo '<div id="prenom"> <a href="profil.php">'.$donnees['prenom'].'</a> </div>';
  echo '<a href="profil.php"> <img src="IMG/avatar/'.$donnees['photo'].'" alt="avatar" width="40" /></a>';
  echo '<a class="boutton" href="deconnexion.php"> Se déconnecter  </a></li>';
}
echo'</div>';
} else{ ?>
<div id="co1">

 <a class="boutton" href="inscription.php">   Inscription  </a></li> 
 <a class="boutton" href="connexion.php">  Se connecter </a></li>
</div>
<?php }?>
<div id="menu">
  <ul id="onglets">
   <li class="active"><a href="Home.php"> Accueil </a></li>
      <li><a href="Group.php"> Rechercher un groupe </a></li>
    <li><a href="creergroupe.php"> Créer un groupe </a></li>
    <li><a href="Forums.php"> Forum</a></li>
    <li><a href="Help.php"> Aide</a></li>
  </ul>
</div>
</header>
     
             <section>
 
                   <div id='titre' style="position:relative; left:5%;
                                 top:5%;
                 width:20%;
    height:15%;
    background-color: #404040;">
                     <h2> &nbsp;&nbsp;&nbsp;&nbsp;  <em><u> Forum </u></em> </h2> 
                    
                     &nbsp;&nbsp;&nbsp;&nbsp; Choisis ton sport:
                        </br>

                     
&nbsp;&nbsp;&nbsp; <select id="selectbox" name="sport" size=1 onchange ="javascript:location.href=this.value;">
               <option value="#"> </option>
               <?php
$req = $bdd->query('SELECT s.id AS id,s.texte AS texte,s.id_categorie,c.id AS idd,c.type_sport AS type_sport FROM sujet s INNER JOIN categorie c on s.id_categorie=c.id ORDER BY c.type_sport');
while ($donnees = $req->fetch()){

if(empty($cat_en_cours)){
echo '<optgroup label="'.$donnees['type_sport'].'" >';    
$cat_en_cours = $donnees['type_sport'];
echo '</optgroup>';   }
   
if($cat_en_cours!=$donnees['type_sport']){    
echo '<optgroup label="'.$donnees['type_sport'].'" >';    
$cat_en_cours = $donnees['type_sport'];   } 
  
            echo'</optgroup> <option name="sport" value="rubrique.php?sujet='.htmlspecialchars($donnees['id']).'" method="post">'.htmlspecialchars($donnees['texte']).'</option>';  } 
echo '</select>';
?>
<script type="text/javascript">
    window.onload = function(){
        location.href=document.getElementById("selectbox").value;
    }       
</script>
</div><div id='faire' style="position:relative; left:55%;
                                 top:-13%;
                 width:40%;
    height:20%;
    background-color: #404040;">
<?php
$req = $bdd->query('SELECT id,texte FROM sujet ORDER BY id');
while ($donnees = $req->fetch())
{ 

if($_GET['sujet']==htmlspecialchars($donnees['id'])){
echo '<h2>&nbsp;&nbsp;&nbsp;&nbsp;'.htmlspecialchars($donnees['texte']).'</h2>';
}
              
} // Fin de la boucle des billets
$req->closeCursor();
?>


<form action="rubrique_post.php?sujet=<?php echo $_GET['sujet']; ?>" method="post">


        <p>
        <label for="titre">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Titre de votre rubrique</label> : &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="titre" id="titre" /></br>
        <label for="description">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Description de votre rubrique</label> :  <input type="text" name="description" id="description" /></br>

        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" value="Envoyer" />
    </p>
</form>
</div>

       <div id='titre' style="position:relative; left:5%;
                                 top:-5%;
                 width:80%;
    height:65%;
    background-color: #404040;
    overflow:scroll;"> <h2> <em> &nbsp; &nbsp; &nbsp; Rubriques du forum : <em> </h2> </br>
 


<?php
// On récupère les 5 derniers billets
$req = $bdd->query('SELECT r.id AS id , r.titre AS titre, r.description AS description, r.id_sujet AS id_sujet, r.id_utilisateur AS id_utilisateur ,u.id AS idd, u.prenom AS prenom, u.nom AS nom  FROM rubrique r INNER JOIN utilisateur u ON r.id_utilisateur=u.id ORDER BY r.id DESC');

while ($donnees = $req->fetch())
{
if($donnees['id_sujet']==$_GET['sujet'] && $donnees['id_utilisateur']==$donnees['idd'] ){

?>
    <div style="position:relative; left:5%; top:-5%; width:80%; height:45%;  border: 6px solid #337ab7; border-radius: 5px; overflow-top:scroll; ">
    <h3>
          &nbsp; &nbsp; &nbsp; <?php  
echo htmlspecialchars($donnees['titre']);
 ?>
    </h3>
    
    <p>
    &nbsp; &nbsp; &nbsp;
    <?php
    // On affiche le contenu du billet
    echo nl2br(htmlspecialchars($donnees['description']));
    ?>
    </br></br>
    &nbsp; &nbsp; &nbsp; <em><?php echo htmlspecialchars($donnees['prenom'])?> &nbsp;<?php echo htmlspecialchars($donnees['nom'][0]);?> </em></br>
    &nbsp; &nbsp; &nbsp; <em><a href="message.php?sujet=<?php echo $_GET['sujet'];?>&rubrique=<?php echo $donnees['id'];?>"> Commentaires</a></em> <div style="position:relative; left:88%; top:-75%;"><?php echo '<form action="bdabusr.php?sujet='.$_GET['sujet'].'&id_rubrique='.$donnees['id'].'" method="POST">';
echo'<input type="submit" value="Signaler un abus" /> </br>';
echo'</form>';
    ?> 
    </div>
    </p>
    </div>
    </br> 
<?php
}
} // Fin de la boucle des billets
$req->closeCursor();
?>
</div>
</br></br>


                    
                


</section>
<footer>
</br>
<a href="https://www.facebook.com/"> <img  src="0facebook-miniature.jpg" alt="Photo de facebook" title="Facebook"/> </a>
<a href="https://www.twitter.com/"> <img src="Twitter_logo.png" alt="Photo de twitter" title="Twitter"/> </a>
<p>qui sommes-nous ? mention légale  condition d'utilisation</p>

</footer>
</body>
</html>