<?php
session_start();
try
{
	$bdd = new PDO('mysql:host=localhost;dbname=le_site_du_sport;charset=utf8', 'root', 'root');
}
catch (Exception $e)
{
        die('Erreur : ' . $e->getMessage());
}

$req = $bdd->prepare('DELETE FROM utilisateur_groupe WHERE id_groupe=?');
$req->execute(array(
	$_GET['nom']
	));
$req->closeCursor();
$req = $bdd->prepare('UPDATE groupe SET id_utilisateur=NULL,id_sport=NULL WHERE id=?');
$req->execute(array(
	$_GET['nom']
	));
$req->closeCursor();
$req = $bdd->prepare('DELETE FROM evenement WHERE id_groupe=?');
$req->execute(array(
	$_GET['nom']
	));
$req->closeCursor();
$req = $bdd->prepare('DELETE FROM groupe WHERE id=?');
$req->execute(array(
	$_GET['nom']
	));
$req->closeCursor();
header('Location: Group.php');


?>
	