<?php
 try{
     $bdd = new PDO('mysql:host=localhost;dbname=le_site_du_sport', 'root','root');
 } catch(Exception $e) {
   die('Erreur : ' . $e->getMessage());
 }
$req=$bdd->query('SELECT * FROM groupe');
while($donnees = $req->fetch()){
 echo '</br>'.$donnees['nomgroupe'];
}
?>