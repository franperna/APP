<?php
session_start();
try
{
	$bdd = new PDO('mysql:host=localhost;dbname=le_site_du_sport;charset=utf8', 'root', 'root');
}
catch (Exception $e)
{
        die('Erreur : ' . $e->getMessage());
}

htmlentities($nom = $_POST['nom']);
htmlentities($prenom = $_POST['prenom']);
$req = $bdd->query('SELECT id,nom,prenom FROM utilisateur WHERE prenom= "'.$prenom.'" AND nom= "'.$nom.'"  ');
while ($donnees = $req->fetch())
{ 
$rr=htmlspecialchars($donnees['id']);
}
$req->closeCursor();
$req = $bdd->prepare('DELETE FROM utilisateur_groupe WHERE id_utilisateur=? AND id_groupe=?');
$req->execute(array(
	$rr,
	$_GET['nom']));
$req->closeCursor();

header('Location: profilgroupe.php?nom='.$_GET['nom']);


?>
	