<?php 
try
{
	$bdd = new PDO('mysql:host=localhost;dbname=le_site_du_sport;charset=utf8', 'root', 'root');
}
catch (Exception $e)
{
        die('Erreur : ' . $e->getMessage());
}
// Hachage du mot de passe
if(isset($_POST['Envoyer']))

    {
      //print_r($_POST);
htmlentities($mot_de_passe = $_POST['mot_de_passe']);
htmlentities($nom = $_POST['nom']);
// Hachage du mot de passe
$pass_hache = sha1($_POST['mot_de_passe']);
// Vérification des identifiants
$req = $bdd->prepare('SELECT id,nom,prenom,mail,mot_de_passe,age,description,civilite,ville FROM utilisateur WHERE nom = ? AND mot_de_passe = ?');
$req->execute(array(
     $nom,
     $pass_hache));
  
$resultat = $req->fetch();
if (!$resultat)
{
    echo 'Mauvais identifiant ou mot de passe !';
  
}
else
{
    session_start();
  $_SESSION['id'] = $resultat['id'];
  $_SESSION['nom'] = $resultat['nom'];
  $_SESSION['prenom'] =$resultat['prenom'];
  $_SESSION['mot_de_passe'] = $resultat['mot_de_passe'];
  $_SESSION['mail'] = $resultat['mail'];
  $_SESSION['age']=$resultat['age'];
  $_SESSION['description']=$resultat['description'];
  $_SESSION['civilite']=$resultat['civilite'];
  $_SESSION['ville']=$resultat['ville'];

  //print_r($_SESSION);
  
    echo 'Vous êtes connecté !';
  header("Location: profil.php");
}
}
?>