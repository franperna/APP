
<?php
try
{
    $bdd = new PDO('mysql:host=localhost;dbname=le_site_du_sport;charset=utf8', 'root', 'root');
}
catch (Exception $e)
{
        die('Erreur : ' . $e->getMessage());
}
 session_start();
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <link rel="stylesheet" href="en-tete3.css">
  <title>accueil</title>
</head>
<body background="fond.jpg" style="width:100%">
<header>
<div class="container" style="background-color:#404040;color:white;width:100%;position:fixed;z-index:3;">
<h2 style="text-align:center;"> Qui seront vos prochains compagnons de sport?</h2>

<div id="im">
    <img class="imageconnexion" src="logome.jpg" style="height:115px; width:350px;" alt="" />
</div>
</div>
<br>

<?php if(isset($_SESSION['id'])){
$req = $bdd->query('SELECT id,prenom,photo FROM utilisateur WHERE id="'.$_SESSION['id'].'" ');
echo '<div id="co1">';
while ($donnees = $req->fetch())
{ echo '<div id="prenom"> <a href="profil.php">'.$donnees['prenom'].'</a> </div>';
  echo '<a href="profil.php"> <img src="IMG/avatar/'.$donnees['photo'].'" alt="avatar" width="40" /></a>';
  echo '<a class="boutton" href="deconnexion.php"> Se déconnecter  </a></li>';
}
echo'</div>';
} else{ ?>
<div id="co1">

 <a class="boutton" href="inscription.php">   Inscription  </a></li> 
 <a class="boutton" href="connexion.php">  Se connecter </a></li>
</div>
<?php }?>
<div id="menu">
  <ul id="onglets">
   <li class="active"><a href="Home.php"> Accueil </a></li>
      <li><a href="Group.php"> Rechercher un groupe </a></li>
    <li><a href="creergroupe.php"> Créer un groupe </a></li>
    <li><a href="Forums.php"> Forum</a></li>
    <li><a href="Help.php"> Aide</a></li>
  </ul>
</div>
</header>


<form method="post"  enctype="multipart/form-data">
<section>
<div id='titre' style="position:relative; left:35%;
                                 top:15%;
                 width:40%;
    height:65%;
    background-color: #404040;
    overflow:scroll;">

</br>
       <h2> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Modification du profil:</h2>

<p>
</br>
<label for="firstname">&nbsp;&nbsp;&nbsp;Nom :</label>&nbsp;&nbsp;&nbsp;
<input type ="text" name="nom"  value="<?php if (isset($_SESSION['nom'])){echo htmlentities($_SESSION['nom']);} ?>"id="nom" placeholder="Nom.." required/>
</br>
</br>
<label for="lastname">&nbsp;&nbsp;&nbsp;Prenom :</label>
<input type ="text" name="prenom"  value="<?php if (isset($_SESSION['prenom'])){echo htmlentities($_SESSION['prenom']);} ?>"id="prenom2" placeholder="Prenom.." required/>

</br>
</br>
&nbsp;&nbsp;<label> Date de Naissance :  </label><input type="date" name= "birthday" value="<?php if (isset($_SESSION['age'])){echo htmlentities($_SESSION['age']);} ?>" >(jj-mm-aaaa)
</br>
</br>


<label for="ville">&nbsp;&nbsp;&nbsp;Ville :</label>
<input type ="text" name="ville"  value="<?php if (isset($_POST['ville'])){echo htmlentities($_POST['ville']);} ?>"/>

</br>
</br>


<label for="photo">&nbsp;&nbsp;&nbsp;Photo :</label>
<input type="file" name="avatar"/>
<input type="hidden" name="MAX_FILE_SIZE" value="100000">
</br>
</br>
<label for="description">&nbsp;&nbsp;&nbsp; Description : </label><br/> &nbsp;&nbsp; 
<textarea type="text" name="description" value="<?php if (isset($_SESSION['description'])){echo htmlentities($_SESSION['description']);} ?>"id="description"></textarea>

<br/>


<br/>



&nbsp;&nbsp;&nbsp;<input type="submit" name= Envoyer value="Envoyer"/>

</p>

</form>
 <?php 
 if(isset($_POST['Envoyer']))
    {
    
     /* // Je recupere les infos, plus securité pour le code.
        htmlentities($mot_de_passe = $_POST['mot_de_passe']);
        htmlentities($passcon = $_POST['passcon']);
        htmlentities($mail = $_POST['mail']);
        htmlentities($email2 = $_POST['email2']);
        //htmlentities($pseudo= $_POST['pseudo']);
        htmlentities($civilite = $_POST['civilite']);
        htmlentities($prenom = $_POST['prenom']);
        htmlentities($nom = $_POST['nom']);
        htmlentities($birthday = $_POST['birthday']);
        //htmlentities($user_post_office_box = $_POST['user_post_office_box']);
       // htmlentities($city = $_POST['city']);
        htmlentities($Regle=$_POST['Regle']);
        htmlentities($description=$_POST['description']);
    */
        if(!empty($_POST['nom']))
            echo "hjjkl";
        { htmlentities($nom = $_POST['nom']);
            $req = $bdd->prepare('SELECT id FROM utilisateur WHERE mail = ? ');
            $req->execute(array(
            $_SESSION['mail']));
                        //print_r ($req['id']);
                        //var_dump $req;
                        //die();
            $resul= $req->fetch();
                            
            var_dump($resul['id']);
                        
                        
                    $reponse = $bdd->query('UPDATE  utilisateur SET nom=\''.$nom.'\' WHERE id=\''.$resul['id'].'\'');
                    $_SESSION['nom'] = $_POST['nom'];
                    echo "vos information personnelles ont bien été modifiées";
                    //header('location: profil.php');
                      //echo '<script type="text/javascript">window.alert("'.$message0.'"); window.location.href="testinscription.php";</script>';
        }   
        if(!empty($_POST['prenom']))
        { htmlentities($prenom = $_POST['prenom']);
            $req = $bdd->prepare('SELECT id FROM utilisateur WHERE mail = ? ');
            $req->execute(array(
            $_SESSION['mail']));
                        //print_r ($req['id']);
                        //var_dump $req;
                        //die();
            $resul= $req->fetch();
                            
            var_dump($resul['id']);
                        
                        
                    $reponse = $bdd->query('UPDATE  utilisateur SET prenom=\''.$prenom.'\' WHERE id=\''.$resul['id'].'\'');
                    $_SESSION['prenom'] = $_POST['prenom'];
                    echo "Vos informations personnelles ont bien été modifiées.";
        }
                if(!empty($_POST['ville']))
        { htmlentities($ville = $_POST['ville']);
            $req = $bdd->prepare('SELECT id FROM utilisateur WHERE mail = ? ');
            $req->execute(array(
            $_SESSION['mail']));
                        //print_r ($req['id']);
                        //var_dump $req;
                        //die();
            $resul= $req->fetch();
                            
            var_dump($resul['id']);
                        
                        
                    $reponse = $bdd->query('UPDATE  utilisateur SET ville=\''.$ville.'\' WHERE id=\''.$resul['id'].'\'');
                    $_SESSION['ville'] = $_POST['ville'];
                    echo "Vos informations personnelles ont bien été modifiées.";
        }
        if(!empty( $_POST['birthday']))
        { htmlentities($birthday = $_POST['birthday']);
            $req = $bdd->prepare('SELECT id FROM utilisateur WHERE mail = ? ');
            $req->execute(array(
            $_SESSION['mail']));
                        //print_r ($req['id']);
                        //var_dump $req;
                        //die();
            $resul= $req->fetch();
                            
            var_dump($resul['id']);
                        
                        
                    $reponse = $bdd->query('UPDATE  utilisateur SET age=\''.$birthday.'\' WHERE id=\''.$resul['id'].'\'');
                    $_SESSION['age'] = $_POST['birthday'];
                  echo "vos information personnelles ont bien été modifiées";
        } 
        
        //photo
        $req = $bdd->prepare('SELECT id FROM utilisateur WHERE mail = ? ');
            $req->execute(array(
            $_SESSION['mail']));
                        //print_r ($req['id']);
                        //var_dump $req;
                        //die();
            $resul= $req->fetch();
                            
            var_dump($resul['id']);
                        
    
        if(isset($_FILES['avatar']) AND !empty($_FILES['avatar']['name'])){
        $taillemax=2097152;
        $extensionsvalides=array('jpg','jpeg','gif','png');
        if($_FILES['avatar']['size'] <= $taillemax){
        $extensionupload = strtolower(substr(strrchr($_FILES['avatar']['name'],'.'),1)); // check si tout minuscule et l'extension
            if(in_array($extensionupload, $extensionsvalides)){
            $chemin = "IMG/avatar/".$resul['id'].".".$extensionupload;
            $resultat = move_uploaded_file($_FILES['avatar']['tmp_name'],$chemin); //stockage temporaire
            if($resultat){
            $req = $bdd->prepare('UPDATE utilisateur SET photo = :avatar WHERE id = :idutilisateur');
           $req-> execute(array(
             'avatar' => $resul['id'].".".$extensionupload,
             'idutilisateur' => $resul['id']
           ));
           
         }
         else{
           $msg = "Erreur lors de l'importation de la photo de profil...";
         }
       }
       else{
         $msg = "Votre photo de profil doit être au format indiqué !";
       }
     }
     else{
       $msg = "Votre photo de profil ne doit pas dépasser 2 Mo !";
     }
   }
    
        if(!empty($_POST['description']))
        { htmlentities($description = $_POST['description']);
            $req = $bdd->prepare('SELECT id FROM utilisateur WHERE mail = ? ');
            $req->execute(array(
            $_SESSION['mail']));
                        //print_r ($req['id']);
                        //var_dump $req;
                        //die();
            $resul= $req->fetch();
                            
            var_dump($resul['id']);
                        
                        
                    $reponse = $bdd->query('UPDATE  utilisateur SET description=\''.$description.'\' WHERE id=\''.$resul['id'].'\'');
                    $_SESSION['description'] = $_POST['description'];
                  echo "vos information personnelles ont bien été modifiées";
        }
        header('location: profil.php');
    }   
    
?>
</div>
</section>
<footer>
</br>
<a href="https://www.facebook.com/"> <img  src="0facebook-miniature.jpg" alt="Photo de facebook" title="Facebook"/> </a>
<a href="https://www.twitter.com/"> <img src="Twitter_logo.png" alt="Photo de twitter" title="Twitter"/> </a>
<p>qui sommes-nous ? mention légale  condition d'utilisation</p>

</footer>
</form>
</body>
</html>