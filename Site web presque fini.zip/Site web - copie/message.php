<?php 
// Connexion à la base de données
try
{
    $bdd = new PDO('mysql:host=localhost;dbname=le_site_du_sport;charset=utf8', 'root', 'root');
}
catch(Exception $e)
{
        die('Erreur : '.$e->getMessage());
}
session_start(); ?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <link rel="stylesheet" href="en-tete3.css">
  <title>accueil</title>
</head>
<body background="fond.jpg" style="width:100%">
<header>
<div class="container" style="background-color:#404040;color:white;width:100%;position:fixed;z-index:3;">
<h2 style="text-align:center;"> Qui seront vos prochains compagnons de sport?</h2>

<div id="im">
    <img class="imageconnexion" src="logome.jpg" style="height:115px; width:350px;" alt="" />
</div>
</div>
<br>

<?php if(isset($_SESSION['id'])){
$req = $bdd->query('SELECT id,prenom,photo FROM utilisateur WHERE id="'.$_SESSION['id'].'" ');
echo '<div id="co1">';
while ($donnees = $req->fetch())
{ echo '<div id="prenom"> <a href="profil.php">'.$donnees['prenom'].'</a> </div>';
  echo '<a href="profil.php"> <img src="IMG/avatar/'.$donnees['photo'].'" alt="avatar" width="40" /></a>';
  echo '<a class="boutton" href="deconnexion.php"> Se déconnecter  </a></li>';
}
echo'</div>';
} else{ ?>
<div id="co1">

 <a class="boutton" href="inscription.php">   Inscription  </a></li> 
 <a class="boutton" href="connexion.php">  Se connecter </a></li>
</div>
<?php }?>
<div id="menu">
  <ul id="onglets">
   <li class="active"><a href="Home.php"> Accueil </a></li>
      <li><a href="Group.php"> Rechercher un groupe </a></li>
    <li><a href="creergroupe.php"> Créer un groupe </a></li>
    <li><a href="Forums.php"> Forum</a></li>
    <li><a href="Help.php"> Aide</a></li>
  </ul>
</div>
</header>
     
             <section>

                     

<div id='faire' style="position:relative; left:55%;
                                 top:5%;
                 width:40%;
    height:20%;
    background-color: #404040;">
<form action="message_post.php?sujet=<?php echo $_GET['sujet'];?>&rubrique=<?php echo $_GET['rubrique']; ?>" method="post">
        <p>
        <h2>&nbsp; &nbsp; &nbsp;Commentaires </h2>
        
        <label for="texte">&nbsp; &nbsp; &nbsp;Votre commentaire</label> : <input type="text" name="texte" id="texte" /></br>

        &nbsp; &nbsp; &nbsp;<input type="submit" value="Envoyer" />
    </p>

</form>

         <p>&nbsp;<a href="rubrique.php?sujet=<?php echo $_GET['sujet'];?>">Retour à la liste des billets</a></p>
 </div>


 <div id='titre' style="position:relative; left:5%;
                                 top:10%;
                 width:80%;
    height:60%;
    background-color: #404040;
    overflow:scroll;">

<?php

$req = $bdd->query('SELECT r.id AS id , r.titre AS titre, r.description AS description, r.id_sujet AS id_sujet, r.id_utilisateur AS id_utilisateur ,u.id AS idd, u.prenom AS prenom, u.nom AS nom FROM rubrique r INNER JOIN utilisateur u ON r.id_utilisateur=u.id ORDER BY r.id DESC');
while($donnees = $req->fetch()){

if($donnees['id']==$_GET['rubrique'] && $donnees['id_utilisateur']==$donnees['idd'] ){
?>
 <div style="position:relative; left:5%; top:5%; width:80%; height:45%;  border: 6px solid #337ab7; border-radius: 5px; overflow-top:scroll;">
    <h3>
          &nbsp; &nbsp; &nbsp; <?php  
echo htmlspecialchars($donnees['titre']);
 ?>
    </h3>
    
    <p>
    &nbsp; &nbsp; &nbsp;
    <?php
    // On affiche le contenu du billet
    echo nl2br(htmlspecialchars($donnees['description']));
    ?>
    </br></br>
    &nbsp; &nbsp; &nbsp; <em><?php echo htmlspecialchars($donnees['prenom'])?> &nbsp;<?php echo htmlspecialchars($donnees['nom'][0]);?> </em></br>
    &nbsp; &nbsp; &nbsp;  <div style="position:relative; left:88%; top:-82%;"><?php echo '<form action="bdabusr.php?sujet='.$_GET['sujet'].'&id_rubrique='.$donnees['id'].'" method="POST">';
echo'<input type="submit" value="Signaler un abus" /> </br>';
echo'</form>';
    ?> 
    </div>
    </p>
    </div>
    </br> 
<?php
}
}
$req->closeCursor(); // Important : on libère le curseur pour la prochaine requête

// Récupération des commentaires
$req = $bdd->query('SELECT m.id AS id, m.texte AS texte, DATE_FORMAT(m.date, \'%d/%m/%Y à %Hh%imin%ss\') AS date_message_fr,m.id_rubrique AS id_rubrique, m.id_utilisateur AS id_utilisateur, u.id AS idd, u.prenom AS prenom, u.nom AS nom FROM message m INNER JOIN utilisateur u ON m.id_utilisateur=u.id ORDER BY m.date DESC');

while ($donnees = $req->fetch())
{
if($donnees['id_rubrique']==$_GET['rubrique'] && $donnees['id_utilisateur']==$donnees['idd'] ){
?>
<p>&nbsp; &nbsp; <?php echo nl2br(htmlspecialchars($donnees['texte'])); ?></p>&nbsp; &nbsp;
<em> <?php echo htmlspecialchars($donnees['prenom'])?> &nbsp;<?php echo htmlspecialchars($donnees['nom'][0])?> &nbsp; &nbsp; &nbsp; le <?php echo $donnees['date_message_fr']; echo '<form action="bdabusm.php?sujet='.$_GET['sujet'].'&rubrique='.$_GET['rubrique'].'&id_message='.$donnees['id'].'" method="POST">';?></em>
<p><?php 
echo' &nbsp;  <input type="submit" value="Signaler un abus" /> </br> </br> </br>';
echo'</form>';?></p>
<?php
} 
}// Fin de la boucle des commentaires
$req->closeCursor();
?>

</div></br></br>
                    
            
</section>
                <footer>
</br>
<a href="https://www.facebook.com/"> <img  src="0facebook-miniature.jpg" alt="Photo de facebook" title="Facebook"/> </a>
<a href="https://www.twitter.com/"> <img src="Twitter_logo.png" alt="Photo de twitter" title="Twitter"/> </a>
<p>qui sommes-nous ? mention légale  condition d'utilisation</p>

</footer>
        </div>
        
</body>
</html>
