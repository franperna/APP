
 <?php
try
{
	$bdd = new PDO('mysql:host=localhost;dbname=le_site_du_sport;charset=utf8', 'root', 'root');
}
catch (Exception $e)
{
        die('Erreur : ' . $e->getMessage());
}
session_start();
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <link rel="stylesheet" href="en-tete3.css">
  <title>accueil</title>
</head>
<body background="fond.jpg" style="width:100%">
<header>
<div class="container" style="background-color:#404040;color:white;width:100%;position:fixed;z-index:3;">
<h2 style="text-align:center;"> Qui seront vos prochains compagnons de sport?</h2>

<div id="im">
    <img class="imageconnexion" src="logome.jpg" style="height:115px; width:350px;" alt="" />
</div>
</div>
<br>

<?php if(isset($_SESSION['id'])){
$req = $bdd->query('SELECT id,prenom,photo FROM utilisateur WHERE id="'.$_SESSION['id'].'" ');
echo '<div id="co1">';
while ($donnees = $req->fetch())
{ echo '<div id="prenom"> <a href="profil.php">'.$donnees['prenom'].'</a> </div>';
  echo '<a href="profil.php"> <img src="IMG/avatar/'.$donnees['photo'].'" alt="avatar" width="40" /></a>';
  echo '<a class="boutton" href="deconnexion.php"> Se déconnecter  </a></li>';
}
echo'</div>';
} else{ ?>
<div id="co1">

 <a class="boutton" href="inscription.php">   Inscription  </a></li> 
 <a class="boutton" href="connexion.php">  Se connecter </a></li>
</div>
<?php }?>
<div id="menu">
  <ul id="onglets">
   <li class="active"><a href="Home.php"> Accueil </a></li>
      <li><a href="Group.php"> Rechercher un groupe </a></li>
    <li><a href="creergroupe.php"> Créer un groupe </a></li>
    <li><a href="Forums.php"> Forum</a></li>
    <li><a href="Help.php"> Aide</a></li>
  </ul>
</div>
</header>
<body>
<section>
<div style="position:relative; left:3%;
                                 top:5%;
                 width:30%;
    height:65%;
    background-color: #404040;
    overflow:scroll;">
<?php
$req = $bdd->query('SELECT g.ville AS ville,g.photo AS photo,g.id_sport AS id_sport,g.id AS id, u.id AS idd, s.id AS iddd,g.nomgroupe AS nomgroupe, g.jour AS jour, g.journee AS journee, g.club AS club,g.description AS description,g.id_utilisateur AS id_utilisateur,g.id_sport AS id_sport , u.nom AS nomutilisateur, u.prenom AS prenomutilisateur, s.type AS sport FROM groupe g INNER JOIN utilisateur u ON g.id_utilisateur=u.id INNER JOIN sport s ON g.id_sport=s.id');
while ($donnees = $req->fetch())
{ 

if($_GET['nom']==$donnees['id'] && $donnees['id_utilisateur']==$donnees['idd'] && $donnees['id_sport']==$donnees['iddd'])
{
echo '<h3> Nom du groupe:'.htmlspecialchars($donnees['nomgroupe']).'</h3>';
echo '<h3> Leader:'.htmlspecialchars($donnees['nomutilisateur']).'&nbsp;'.htmlspecialchars($donnees['prenomutilisateur']).'</h3>';
echo '<h3> Sport:'.htmlspecialchars($donnees['sport']).'</h3>';
echo '<h3> Jour:'.htmlspecialchars($donnees['jour']).'</h3>';
echo '<h3> Journée:'.htmlspecialchars($donnees['journee']).'</h3>';
echo '<h3> Ville:'.htmlspecialchars($donnees['ville']).'</h3>';
echo '<h3> Club:'.htmlspecialchars($donnees['club']).'</h3>';
echo '<h3> Description:'.htmlspecialchars($donnees['description']).'</h3>';
echo '<h3> Photo:<img id="photogroupe" src="IMG/groupe/'.htmlspecialchars($donnees['photo']).'" alt="Photo de sport" title="Le site du sport"/></h3>';

$_SESSION['nomgroupe']=$donnees['nomgroupe'];
$_SESSION['nomutilisateur']=$donnees['nomutilisateur'];
$_SESSION['sport']=$donnees['id_sport'];
$_SESSION['jour']=$donnees['jour'];
$_SESSION['journee']=$donnees['journee'];
$_SESSION['villeg']=$donnees['ville'];
$_SESSION['club']=$donnees['club'];
$_SESSION['descriptiong']=$donnees['description'];
$_SESSION['photog']=$donnees['photo'];
}

              
} // Fin de la boucle des billets
$req->closeCursor();
echo'</div>';
echo'<div style="position:relative; left:67%;
                                 top:-60%;
                 width:30%;
    height:65%;
    background-color: #404040;
    overflow:scroll;">';
echo'<h1> Evenement </h1>';
$req = $bdd->query('SELECT id,id_groupe,date,description,titre FROM evenement e  ORDER BY id DESC');
while ($donnees = $req->fetch())
{ 

if ($donnees['id_groupe']==$_GET['nom'])
{

echo '<h2> Titre:'.htmlspecialchars($donnees['titre']).'</h2>';
echo '<h2> Date:'.htmlspecialchars($donnees['date']).'</h2>';
echo '<h2> Description:'.htmlspecialchars($donnees['description']).'</h2>';
} 
}// Fin de la boucle des billets
$req->closeCursor();
?>
</div>
<?php
$req = $bdd->query('SELECT g.id AS id, u.id AS idd,g.id_utilisateur AS id_utilisateur FROM groupe g INNER JOIN utilisateur u ON g.id_utilisateur=u.id');
while ($donnees = $req->fetch())
{ 

if($_GET['nom']==$donnees['id'] && $donnees['id_utilisateur']==$_SESSION['id'])
{
echo'<div style="position:relative; left:15%;
                                 top:-57%;
                 width:80%;
    height:25%;
    background-color: #404040;
    overflow:scroll;">';
echo '<a href=modificationgroupe.php?nom='.$_GET['nom'].'> Modifier mes paramètres </a> </br>'; 
echo'<a href=evenement.php?nom='.$_GET['nom'].'> Créer un évènement </a>';
echo '<form action="bdleader.php?nom='.$_GET['nom'].'" method="post">';
echo'Désigner un autre leader:';
echo'<label> Rentrer son nom:  </label> 
            <input type="text" name="nom" id="nom" placeholder="" size="20" maxlength="50" />';
echo'<label> Rentrer son prenom:  </label> 
            <input type="text" name="prenom" id="prenom" placeholder="" size="20" maxlength="50" />';

echo'<input type="submit" value="Valider" /> </br>';
echo'</form>';

echo '<form action="bdprofilgroupe3.php?nom='.$_GET['nom'].'" method="post">';
echo'<input type="submit" value="Supprimer le groupe" /> </br>';
echo'</form>';

echo '<form action="bdprofilgroupe4.php?nom='.$_GET['nom'].'" method="post">';
echo'Supprimer un membre du groupe:';
echo'<label> Rentrer son nom:  </label> 
            <input type="text" name="nom" id="nom" placeholder="" size="20" maxlength="50" />';
echo'<label> Rentrer son prenom:  </label> 
            <input type="text" name="prenom" id="prenom" placeholder="" size="20" maxlength="50" />';

echo'<input type="submit" value="Valider" /> </br>';
echo'</form>';

echo '<form action="bdprofilgroupe5.php?nom='.$_GET['nom'].'" method="post">';
echo'Inviter un utilisateur à rejoindre le groupe:';
echo'<label> Rentrer son nom:  </label> 
            <input type="text" name="nom" id="nom" placeholder="" size="20" maxlength="50" />';
echo'<label> Rentrer son prenom:  </label> 
            <input type="text" name="prenom" id="prenom" placeholder="" size="20" maxlength="50" />';

echo'<input type="submit" value="Valider" /> </br>';
echo'</form>';
echo'</div>' ;
}

} // Fin de la boucle des billets
$req->closeCursor();
?>
<?php
$n=0;
$req = $bdd->query('SELECT g.id AS id, u.id AS idd,g.id_utilisateur AS id_utilisateur FROM groupe g INNER JOIN utilisateur u ON g.id_utilisateur=u.id');
while ($donnees = $req->fetch())
{ 

if($_GET['nom']==$donnees['id'] && $donnees['id_utilisateur']==$_SESSION['id'])
{
  echo'<div style="position:relative; left:36%;
                                 top:-150%;
                 width:30%;
    height:65%;
    background-color: #404040;
    overflow:scroll;">';
    $n=$n+1;
  }}
if($n!=1){
echo'<div style="position:relative; left:36%;
                                 top:-125%;
                 width:30%;
    height:65%;
    background-color: #404040;
    overflow:scroll;">';
}
$req->closeCursor();
$req = $bdd->query('SELECT id_utilisateur,id_groupe FROM utilisateur_groupe');
$ab=0;
while ($donnees = $req->fetch())
{ 

if($donnees['id_utilisateur']==$_SESSION['id'] && $_GET['nom']==$donnees['id_groupe'])
{
 echo 'Vous appartenez à ce groupe </br>'; 
 $ab=$ab+1;
 echo '<form action="bdprofilgroupe2.php?nom='.$_GET['nom'].'" method="post">';
 echo'<input type="submit" value="Se désinscrire du groupe" /> </br>';
 echo'</form>';
}

}
$req->closeCursor();

if($ab!=1){
echo '<form action="bdprofilgroupe.php?nom='.$_GET['nom'].'" method="post">';
echo'<input type="submit" value="S\'inscrire au groupe" /> </br>';
echo'</form>';
}

$req = $bdd->query('SELECT u.photo AS photo, ug.id_utilisateur AS id_utilisateur ,ug.id_groupe AS id_groupe,u.id AS id,u.prenom AS prenom,u.nom AS nom FROM utilisateur_groupe ug INNER JOIN utilisateur u ON ug.id_utilisateur=u.id');
echo'Liste des personnes présente dans ce groupe:';
while ($donnees = $req->fetch())
{
if($_GET['nom']==$donnees['id_groupe'])
{ echo $donnees['photo'];
  echo '&nbsp';
  echo $donnees['prenom'];
  echo '&nbsp';
  echo $donnees['nom'];
   echo '</br>';}}
$req->closeCursor();

$req = $bdd->query('SELECT id_utilisateur,id_groupe,note FROM utilisateur_groupe');
$ba=0;
while ($donnees = $req->fetch())
{ 

if($donnees['id_utilisateur']==$_SESSION['id'] && $_GET['nom']==$donnees['id_groupe'] && $donnees['note']!=NULL)
{
echo 'Vous avez déjà noté ce groupe </br>'; 
$ba=$ba+1;
}}
$req->closeCursor();
if($ba!=1){
echo '<form action="bdnote.php?nom='.$_GET['nom'].'" method="post">';
echo'   <p>
       <label for="note">Choissisez une note pour ce groupe:</br> Ps: Cette note sera prise en compte que si vous êtes inscrit à ce groupe</label><br />
       <select name="note" id="note">
               <option name="note" value=1>1</option>
               <option name="note" value=2>2</option>
               <option name="note" value=3>3</option>
               <option name="note" value=4>4</option>
               <option name="note" value=5>5</option>
     </select>
   </p>';
echo'<input type="submit" value="Envoyer" /> </br>';
echo'</form>';}

$req = $bdd->query('SELECT id_groupe,AVG(note)AS noteg FROM utilisateur_groupe WHERE id_groupe='.$_GET['nom'].'');
while ($donnees = $req->fetch())
{
echo'Note générale du groupe :'.$donnees['noteg'].'/5';	
}
$req->closeCursor();
?>

<a href="Group.php">Retournez au choix d'un groupe</a>
</div>
</section>
<footer>
</br>
<a href="https://www.facebook.com/"> <img  src="0facebook-miniature.jpg" alt="Photo de facebook" title="Facebook"/> </a>
<a href="https://www.twitter.com/"> <img src="Twitter_logo.png" alt="Photo de twitter" title="Twitter"/> </a>
<p>qui sommes-nous ? mention légale  condition d'utilisation</p>

</footer>
</body>

</html>