<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <link rel="stylesheet" href="controle.css" />
        <title> Le site du sport </title>
    </head>
<body>
<form method="post"  action="bdcontrole.php"  enctype="multipart/form-data">

<div id="a">
<label> Nom: </label> 
                     <input type="text" name="nom" id="nom" placeholder="" size="50" maxlength="50" /> </br> </div>
<div id="b">

Type de permis:
       <select id="selectbox" name="permis" size=1>
               <option name="permis" value="1" method="post">B</option>
               <option name="permis" value="2" method="post">A</option>
               <option name="permis" value="3" method="post">A1</option>
       </select>
</div>
					 </br> </br>
<h2> Quelle requête? </h2>	
 <label for="bd" id='r' style="color:blue;"> Ajouter le conducteur à la base de données</label> <input class='z'type="radio" name="bd" id="bd" value=1/>  </br>
<label for="bd" id='t'style="color:blue;"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Afficher le prix  total des locations par </br> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;catégorie de véhicules </label> <input class='z' type="radio" name="bd" id="bd" value=2/> </span> </br>
<label for="bd" style="color:blue;" id='y'>  Afficher la liste des conducteurs  </label> <input class='z' type="radio" name="bd" id="bd" value=3 />  </br></br> 
</p>
<input type="submit" id="d"value="Envoyer"/>
</form>
</body>
</html>