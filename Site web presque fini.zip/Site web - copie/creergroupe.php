<?php 
// Connexion à la base de données
try
{
    $bdd = new PDO('mysql:host=localhost;dbname=le_site_du_sport;charset=utf8', 'root', 'root');
}
catch(Exception $e)
{
        die('Erreur : '.$e->getMessage());
}
session_start();
$z=0;
if (isset($_POST['valider'])){
if (isset($_SESSION['id'])){
if (isset($_POST['nomgroupe'])) {
  
               $sql = $bdd->query('SELECT nomgroupe FROM groupe WHERE nomgroupe= \'' . $_POST['nomgroupe'] . '\';');  
               //$sql->execute(array('.$nomgroupe.' => $_POST['nomgroupe']));         
              $res = $sql->fetch();

              
              if ($res) {
                  $z=$z+1;
               }else{
            $req = $bdd->prepare('INSERT INTO groupe (description,id_utilisateur,nomgroupe,id_sport,jour,journee,club,ville) VALUES(?,?,?,?,?,?,?,?)');
            $req->execute(array(
              $_POST['description'],
              $_SESSION['id'],
              $_POST['nomgroupe'],
              $_POST['sport'],
              $_POST['jour'],
              $_POST['journee'],
              $_POST['club'],
              ucfirst($_POST['ville'])
              ));
header('Location: Group.php');

        }
   }
   else{
    echo"";
   }
}
else{
header('Location: inscription.php');
}

}


?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <link rel="stylesheet" href="en-tete3.css">
  <title>accueil</title>
</head>
<body background="fond.jpg" style="width:100%">
<header>
<div class="container" style="background-color:#404040;color:white;width:100%;position:fixed;z-index:3;">
<h2 style="text-align:center;"> Qui seront vos prochains compagnons de sport?</h2>

<div id="im">
    <img class="imageconnexion" src="logome.jpg" style="height:115px; width:350px;" alt="" />
</div>
</div>
<br>

<?php if(isset($_SESSION['id'])){
$req = $bdd->query('SELECT id,prenom,photo FROM utilisateur WHERE id="'.$_SESSION['id'].'" ');
echo '<div id="co1">';
while ($donnees = $req->fetch())
{ echo '<div id="prenom"> <a href="profil.php">'.$donnees['prenom'].'</a> </div>';
  echo '<a href="profil.php"> <img src="IMG/avatar/'.$donnees['photo'].'" alt="avatar" width="40" /></a>';
  echo '<a class="boutton" href="deconnexion.php"> Se déconnecter  </a></li>';
}
echo'</div>';
} else{ ?>
<div id="co1">

 <a class="boutton" href="inscription.php">   Inscription  </a></li> 
 <a class="boutton" href="connexion.php">  Se connecter </a></li>
</div>
<?php }?>
<div id="menu">
  <ul id="onglets">
   <li class="active"><a href="Home.php"> Accueil </a></li>
      <li><a href="Group.php"> Rechercher un groupe </a></li>
    <li><a href="creergroupe.php"> Créer un groupe </a></li>
    <li><a href="Forums.php"> Forum</a></li>
    <li><a href="Help.php"> Aide</a></li>
  </ul>
</div>
</header>
      <section>

					<article style="position:relative; left:10%;
                                 top:15%;
                 width:400px;
    height:500px;
    background-color: #404040;">				
				
				<form method="post"  enctype="multipart/form-data">

                     <p> <h2></br>&emsp;&emsp;&emsp;&nbsp;&nbsp;Créer un groupe:</h2> </br> 
                     <label> &emsp;&emsp;&emsp;&nbsp;&nbsp;Nom Du Groupe: </label> 
                     <input type="text" name="nomgroupe" id="nomgroupe" placeholder="" size="20" maxlength="50" /> </p>
<?php if($z!=0){echo " &emsp;&emsp;&emsp;&nbsp; Le  nom du groupe que vous avez utilisé existe déjà ";}?>					 
                     

</br>&emsp;&emsp;&emsp;&nbsp; Sport:
          <select id="selectbox" name="sport" size=1>
          <option value="#"> </option>
          <?php
$req = $bdd->query('SELECT id,type FROM sport ORDER BY id');
while ($donnees = $req->fetch())
{
?>
               <option name="sport" value="<?php echo htmlspecialchars($donnees['id']); ?>" method="post"> <?php echo htmlspecialchars($donnees['type']); ?> </option>
             <?php
} // Fin de la boucle des billets
$req->closeCursor();
?>
         </select>      
  </br>
       </br>


       &emsp;&emsp;&emsp;&nbsp;&nbsp;Jour:
       <select id="selectbox" name="jour" size=1>
               <option name="jour" value="#"> </option>
               <option name="jour" value="Lundi" method="post">Lundi</option>
               <option name="jour" value="Mardi" method="post">Mardi</option>
               <option name="jour" value="Mercredi" method="post">Mercredi</option>
               <option name="jour" value="Jeudi" method="post">Jeudi</option>
               <option name="jour" value="Vendredi" method="post">Vendredi</option>
               <option name="jour" value="Samedi" method="post">Samedi</option>
               <option name="jour" value="Dimanche" method="post">Dimanche</option>
       </select>
					 </br>
					
					 
					
					 
					 </br>
					            &emsp;&emsp;&emsp;&nbsp;  Journée :
<input type="radio" name="journee" id="sport" value=matin /> <label for="journee">matin</label>
<input type="radio" name="journee" id="sport" value=après-midi /> <label for="journee"> après-midi</label>
<input type="radio" name="journee" id="sport" value=soir /> <label for="journee"> soir </label>  
					  </br>

            <label> </br>&emsp;&emsp;&emsp;&nbsp;&nbsp;Ville: </label> 
                     <input type="text" name="ville" id="ville" placeholder="Paris" size="20" maxlength="50" /> </p>
                <p>
                     <label for="club"> &emsp;&emsp;&emsp;&nbsp;&nbsp;Club: </label> 
                     <input type="text" name="club" id="adressegroupe" placeholder="" size="20" maxlength="50" /> </p>
                   
</br>
<label for="description"> &emsp;&emsp;&emsp;&nbsp;&nbsp;Description :</label></br>
&emsp;&emsp;&emsp;&nbsp; <textarea name="description" id="description"></textarea>
<br/>
  <br/>
  </br>
          
                
               
					 &emsp;&emsp;&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&nbsp;&nbsp;<input type="submit" name='valider' value="valider"/>
                    
					</form> 


					</article>
          </section>

<footer>
</br>
<a href="https://www.facebook.com/"> <img  src="0facebook-miniature.jpg" alt="Photo de facebook" title="Facebook"/> </a>
<a href="https://www.twitter.com/"> <img src="Twitter_logo.png" alt="Photo de twitter" title="Twitter"/> </a>
<p> Qui sommes-nous ? &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Mentions légales&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  Conditions générales d'utilisation&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Charte</p>

</footer>
        </div>
    </body>
</html>