
<?php
// Connexion à la base de données
try
{
    $bdd = new PDO('mysql:host=localhost;dbname=controle;charset=utf8', 'root', 'root');
}
catch(Exception $e)
{
        die('Erreur : '.$e->getMessage());
}

if($_POST['bd']==1){


$req = $bdd->prepare('INSERT INTO conducteur(nom, permis_id) VALUES(?,?)');
$req->execute(array($_POST['nom'],$_POST['permis']));
echo $_POST['nom'].' a bien été ajouté dans la base de données';

}

if($_POST['bd']==2){
$req = $bdd->query('SELECT AVG(l.prix) AS prix, c.nom AS nom FROM location l INNER JOIN vehicule v ON l.vehicule_id=v.id INNER JOIN categorie c ON c.id=v.categorie_id GROUP BY v.categorie_id ');
echo 'Voici le prix  total des locations par catégorie de véhicules: </br>';
while ($donnees = $req->fetch()){
    echo htmlspecialchars($donnees['nom']);echo '&nbsp;';
	echo htmlspecialchars($donnees['prix']); echo'</br>';

}
}


if($_POST['bd']==3){
$req = $bdd->query('SELECT nom FROM conducteur ');
echo 'Voici la liste des conducteurs: </br>';
while ($donnees = $req->fetch()){
	echo htmlspecialchars($donnees['nom']);echo'</br>';
}
}
?>
