
<?php session_start();?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <link rel="stylesheet" href="en-tete3.css">
  <title>accueil</title>
</head>
<body background="fond.jpg" style="width:100%">
<header>
<div class="container" style="background-color:#404040;color:white;width:100%;position:fixed;z-index:3;">
<h2 style="text-align:center;"> Qui seront vos prochains compagnons de sport?</h2>

<div id="im">
    <img class="imageconnexion" src="logobis.jpg" style="height:125px; width:400px;" alt="" />
</div>
</div>
<br>

<?php if(isset($_SESSION['id'])){
$req = $bdd->query('SELECT id,prenom,photo FROM utilisateur WHERE id="'.$_SESSION['id'].'" ');
echo '<div id="co1">';
while ($donnees = $req->fetch())
{ echo '<a href="profil.php">'.$donnees['prenom'].'</a>';
  echo '<a href="profil.php">'.$donnees['photo'].'</a>';
  echo  '<a class="boutton" href="deconnexion.php"> Se déconnecter  </a></li>';
}
echo'</div>';
} else{ ?>
<div id="co1">

 <a class="boutton" href="inscription.php"> Inscription   </a></li> 
 <a class="boutton" href="connexion.php"> Se connecter </a></li>
</div>
<?php }?>
<div id="menu">
  <ul id="onglets">
   <li class="active"><a href="Home.php"> Accueil </a></li>
      <li><a href="Group.php"> Rechercher un groupe </a></li>
    <li><a href="creergroupe.php"> Créer un groupe </a></li>
    <li><a href="Forums.php"> Forum</a></li>
    <li><a href="Help.php"> Aide</a></li>
  </ul>
</div>
</header>


<form method ="post" >
<section>
<article>
       <legend>Inscription</legend>

<p>

<label for="firstname">Nom :</label>
<input type ="text" name="nom"  value="<?php if (isset($_SESSION['nom'])){echo htmlentities($_SESSION['nom']);} ?>"id="nom" placeholder="Nom.." requered/>
<br/>
<br/>
<label for="lastname">Prenom :</label>
<input type ="text" name="prenom"  value="<?php if (isset($_SESSION['prenom'])){echo htmlentities($_SESSION['prenom']);} ?>"id="prenom" placeholder="Prenom.."requered/>


<br/>


<br/>
<label for="pass">Mot de passe :</label>
<input type ="password" name="mot_de_passe"  id="mot_de_passe" placeholder="Mot de passe.." required/>
<br/>

<br/>
<label for="passcon">Confirmation mot de passe :</label></td>
<input type ="password" name="passcon"  id="passcon" placeholder="Mot de passe.." required/>

<br/>

<br/>
Sexe :
<input type="radio" name="civilite" id="civilite" value="Homme"/> <label for="masculin">Masculin</label>
<input type="radio" name="civilite" id="civilite" value="femme"/> <label for="feminin">Feminin</label>

<br/>
<br/>



 <label>Date de Naissance  </label><input type="date" name= "birthday" value="<?php if (isset($_POST['date'])){echo htmlentities($_POST['date']);} ?>" max="2016-01-01" min="1900-01-01">(jj-mm-aaaa)<br/>




<br/>
<label for="phone">Numero de telephone :</label>
<input type ="tel" name="phone"  value="<?php if (isset($_POST['phone'])){echo htmlentities($_POST['phone']);} ?>"placeholder="06.."/>
<br/>
<br/>
<label for="email1">Email :</label>
<input type ="email" name="mail"  value="<?php if (isset($_SESSION['mail'])){echo htmlentities($_SESSION['mail']);} ?>"id="email1" placeholder="Email.."requered/>
<br/>

<br/>
<label for="email2">Confirmation Email :</label>
<input type ="email" name="email2" value="<?php if (isset($_SESSION['mail'])){echo htmlentities($_SESSION['mail']);} ?>"id="email2" placeholder="Email.." required/>

<br/>
<br/>
<label for="photo">Photo :</label>
<input type="file" name="logo"/>
<input type="hidden" name="MAX_FILE_SIZE" value="100000">
<br/>

<br/>
<label for="description"> Description </label><br/>
<textarea type="text" name="description" value="<?php if (isset($_POST['description'])){echo htmlentities($_POST['description']);} ?>"id="description"></textarea>

<br/>
<br/>

<input type="checkbox" name="Regle">Je reconnais avoir lu et approuvé les conditions d’utilisation </a></br></br>

<br/>



<input type="submit" name= Envoyer value="Envoyer"/>

</p>

</form>
<?php
try
{
	$bdd = new PDO('mysql:host=localhost;dbname=le_site_du_sport;charset=utf8', 'root', '');
}
catch (Exception $e)
{
        die('Erreur : ' . $e->getMessage());
}
 if(isset($_POST['Envoyer']))
    {


      // Je recupere les infos, plus securité pour le code.
        htmlentities($mot_de_passe = $_POST['mot_de_passe']);
        htmlentities($passcon = $_POST['passcon']);
        htmlentities($mail = $_POST['mail']);
        htmlentities($email2 = $_POST['email2']);
        //htmlentities($pseudo= $_POST['pseudo']);
        htmlentities($civilite = $_POST['civilite']);
        htmlentities($prenom = $_POST['prenom']);
        htmlentities($nom = $_POST['nom']);
        htmlentities($birthday = $_POST['birthday']);

        //htmlentities($user_post_office_box = $_POST['user_post_office_box']);
       // htmlentities($city = $_POST['city']);
        htmlentities($Regle=$_POST['Regle']);
		htmlentities($description=$_POST['description']);

        // empecher les codes php dans la base
      // Je verifie que TOUT les champs sont remplis.
      if(empty($mot_de_passe)||empty($mail)|| empty($Regle)|| empty($prenom) || empty($prenom) || empty($birthday )  || empty($mail)|| empty($description) )
      {
                    echo "Vous devez remplir tout les formulaire";
                      //echo '<script type="text/javascript">window.alert("'.$message0.'"); window.location.href="testinscription.php";</script>';
      }
	  // filter_var permet de verifier la validité de l'email
      else {
          if (filter_var($mail, FILTER_VALIDATE_EMAIL)) {
              $sql = $bdd->prepare('SELECT mail FROM utilisateur WHERE mail = \'' . $mail . '\';');
              $sql->execute(array('.$mail.' => $_POST['mail']));
              $res = $sql->fetch();
              /*if ($res) {
                  $message3 = "L\'Email que vous avez utilisé existe déjà";
                  echo '<script type="text/javascript">window.alert("' . $message3 . '"); window.location.href="testinscription.php";</script>';
              } else {*/
                  if (($mot_de_passe == $passcon) && ($mail == $email2)) {
					  $pass_hache = sha1($_POST['mot_de_passe']);
					  $req = $bdd->prepare('SELECT id FROM utilisateur WHERE mail = ? ');
						$req->execute(array(
						$_POST['mail']));
						//print_r ($req['id']);
						//var_dump $req;
						//die();
						$resul= $req->fetch();
							
						var_dump($resul['id']);
						
						
					$reponse = $bdd->query('UPDATE  utilisateur SET nom=\''.$nom.'\', prenom=\''.$prenom.'\', mail=\''.$mail.'\',mot_de_passe=\''.$pass_hache.'\',age=\''.$birthday.'\',description=\''.$description.'\', civilite=\''.$civilite.'\' WHERE id=\''.$resul['id'].'\'');
					  /*$req = $bdd->prepare('INSERT INTO utilisateur (nom,prenom,mail,mot_de_passe,age,civilite,pseudo) VALUES(?,?,?,?,?,?,?)');
						$req->execute(array(
						$nom,
						$prenom,
						$mail,
						$pass_hache,
						$birthday,
						$civilite,
						$pseudo
					));*/
						
                      //affiche un mot gentil, dans le futur on doit changer pour que ceci apparaisse sur une autre.nom,prenom,mail,mot_de_passe,age,civilite,pseudo
                      $message = "Bonjour $prenom votre compte est bien enregistré";
                      echo '<script type="text/javascript">window.alert("' . $message . '"); window.location.href="testinscription.php";</script>';
                  } else {
                      $message1 = "Les deux mots de passe ou les deux e-mails que vous avez rentrés ne correspondent pas";
                      echo '<script type="text/javascript">window.alert("' . $message1 . '"); window.location.href="testinscription.php";</script>';
                  }
              /*}*/
          } else {
              $message2 = "Votre email n\'est pas valide";
              echo '<script type="text/javascript">window.alert("' . $message2 . '"); //window.location.href="testinscription.php";</script>';
          }
      }
    }

?>
</table>
</div>

</article>
</section>

<footer>
</br>
<a href="https://www.facebook.com/"> <img  src="0facebook-miniature.jpg" alt="Photo de facebook" title="Facebook"/> </a>
<a href="https://www.twitter.com/"> <img src="Twitter_logo.png" alt="Photo de twitter" title="Twitter"/> </a>
<p>qui sommes-nous ? mention légale  condition d'utilisation</p>

</footer>
        </div>


</body>
</html>