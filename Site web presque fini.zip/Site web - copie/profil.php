 <?php 
 try
{
  $bdd = new PDO('mysql:host=localhost;dbname=le_site_du_sport;charset=utf8', 'root', 'root');
}
catch (Exception $e)
{
        die('Erreur : ' . $e->getMessage());
} 
session_start();?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <link rel="stylesheet" href="en-tete3.css">
  <title>accueil</title>
</head>
<body background="fond.jpg" style="width:100%">
<header>
<div class="container" style="background-color:#404040;color:white;width:100%;position:fixed;z-index:3;">
<h2 style="text-align:center;"> Qui seront vos prochains compagnons de sport?</h2>

<div id="im">
    <img class="imageconnexion" src="logome.jpg" style="height:115px; width:350px;" alt="" />
</div>
</div>
<br>

<?php if(isset($_SESSION['id'])){
$req = $bdd->query('SELECT id,prenom,photo FROM utilisateur WHERE id="'.$_SESSION['id'].'" ');
echo '<div id="co1">';
while ($donnees = $req->fetch())
{ echo '<div id="prenom"> <a href="profil.php">'.$donnees['prenom'].'</a> </div>';
  echo '<a href="profil.php"> <img src="IMG/avatar/'.$donnees['photo'].'" alt="avatar" width="40" /></a>';
  echo '<a class="boutton" href="deconnexion.php"> Se déconnecter  </a></li>';
}
echo'</div>';
} else{ ?>
<div id="co1">

 <a class="boutton" href="inscription.php">   Inscription  </a></li> 
 <a class="boutton" href="connexion.php">  Se connecter </a></li>
</div>
<?php }?>
<div id="menu">
  <ul id="onglets">
   <li class="active"><a href="Home.php"> Accueil </a></li>
      <li><a href="Group.php"> Rechercher un groupe </a></li>
    <li><a href="creergroupe.php"> Créer un groupe </a></li>
    <li><a href="Forums.php"> Forum</a></li>
    <li><a href="Help.php"> Aide</a></li>
  </ul>
</div>
</header>
<body>
<section>
<div id='titre' style="position:relative; left:5%;
                                 top:10%;
                 width:40%;
    height:85%;
    background-color: #404040;
    overflow:scroll;">
<?php
      $req = $bdd->prepare('SELECT photo FROM utilisateur WHERE mail = ? ');
      $req->execute(array(
      $_SESSION['mail']));
            //print_r ($req['id']);
            //var_dump $req;
            //die();
      $resul= $req->fetch();
      
      
    if (!empty($resul['photo'])){ ?>
    </br> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      <img src="IMG/avatar/<?php echo $resul['photo'];?>" alt="avatar" height="200" width="170" />
    <?php
    } ?>

<p> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Civilité:&nbsp;<?php if (isset($_SESSION['civilite'])){echo htmlentities($_SESSION['civilite']);} ?></p>

<p> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Nom:&nbsp;<?php if (isset($_SESSION['nom'])){echo htmlentities($_SESSION['nom']);} ?></p>

<p> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Prénom:&nbsp;<?php if (isset($_SESSION['prenom'])){echo htmlentities($_SESSION['prenom']);} ?></p>

<p> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Date de naissance:&nbsp;<?php if (isset($_SESSION['age'])){echo htmlentities($_SESSION['age']);} ?></p>

<p> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;E-mail:&nbsp;<?php if (isset($_SESSION['mail'])){echo htmlentities($_SESSION['mail']);} ?></p>

<p> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Ville:&nbsp;<?php if (isset($_SESSION['ville'])){echo htmlentities($_SESSION['ville']);} ?></p>

<p> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Description:&nbsp;<?php if (isset($_SESSION['description'])){echo htmlentities($_SESSION['description']);} ?></p>

 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="modificationprofil.php" id ="modification">Modifier votre profil</a>
</div>
<article style="position:relative; left:55%;
                                 top:-75%;
                 width:40%;
    height:40%;
    background-color: #404040;
    overflow:scroll;" >
                     <h3>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Planning: </h3> 
<?php 
$req = $bdd->query('SELECT s.id,g.id_sport,g.nomgroupe AS nomgroupe,g.jour AS jour,g.journee AS journee,s.type AS sport, u.id,g.id AS ida,ug.id_utilisateur AS id,ug.id_groupe FROM utilisateur_groupe ug  INNER JOIN groupe g ON g.id=ug.id_groupe INNER JOIN utilisateur u ON u.id=ug.id_utilisateur INNER JOIN sport s ON s.id=g.id_sport ORDER BY g.jour');
while ($donnees = $req->fetch()){
if($donnees['id']==$_SESSION['id']){
  echo '&nbsp;&nbsp;&nbsp; Vous faîtes du &nbsp;'.htmlspecialchars($donnees['sport']).'&nbsp; tous les &nbsp;'.htmlspecialchars($donnees['jour']).'&nbsp;'.htmlspecialchars($donnees['journee']).'avec le groupe &nbsp;<a href="profilgroupe.php?nom='.htmlspecialchars($donnees['ida']).'" >'.htmlspecialchars($donnees['nomgroupe']).' </a> </br>';
  
}

}
?>
</article>
<article style="position:relative; left:55%;
                                 top:-70%;
                 width:40%;
    height:40%;
    background-color: #404040;
    overflow:scroll;" >

                     <h3>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Invitation à rejoindre un groupe: </h3>
                     <?php 
$req = $bdd->query('SELECT i.id AS ide, g.id AS iddd,i.id_invite AS id,i.id_demande,u.id, g.id_utilisateur AS idd, g.nomgroupe AS nomgroupe FROM Invitation i INNER JOIN utilisateur u ON i.id_invite=u.id INNER JOIN groupe g ON i.id_demande=g.id LIMIT 20');
while ($donnees = $req->fetch()){
if($donnees['id']==$_SESSION['id']){
  echo '&nbsp;&nbsp;&nbsp; Le leader de <a id="invitation" onclick="" href="profilgroupe.php?nom='.htmlspecialchars($donnees['iddd']).'">'.htmlspecialchars($donnees['nomgroupe']).'</a> vous invite à rejoindre son groupe &nbsp; </br>';

}

} $req->closeCursor();

//'.$req = $bdd->query('DELETE FROM Invitation WHERE id=?');
//$req->execute(array($donnees['ide']); $req->closeCursor();.'

?> 
</article>
</section>
<footer>
</br>
<a href="https://www.facebook.com/"> <img  src="0facebook-miniature.jpg" alt="Photo de facebook" title="Facebook"/> </a>
<a href="https://www.twitter.com/"> <img src="Twitter_logo.png" alt="Photo de twitter" title="Twitter"/> </a>
<p>qui sommes-nous ? mention légale  condition d'utilisation</p>

</footer>
</body>
</html>