<!DOCTYPE html>
<html>

<head>
		<link rel="stylesheet" href="en-tete3.css"/>
		<meta charset ="utf-8"/>
		<title>Connexionadmin</title>
</head>
<body background="fond.jpg" style="width:100%">
<header>
<div class="container" style="background-color:#404040;color:white;width:100%;position:fixed;z-index:3;">
<h2 style="text-align:center;"> Qui seront vos prochains compagnons de sport?</h2>

<div id="im">
    <img class="imageconnexion" src="logome.jpg" style="height:115px; width:350px;" alt="" />
</div>
</div>
<br>

<?php if(isset($_SESSION['id'])){
$req = $bdd->query('SELECT id,prenom,photo FROM utilisateur WHERE id="'.$_SESSION['id'].'" ');
echo '<div id="co1">';
while ($donnees = $req->fetch())
{ echo '<div id="prenom"> <a href="profil.php">'.$donnees['prenom'].'</a> </div>';
  echo '<a href="profil.php"> <img src="IMG/avatar/'.$donnees['photo'].'" alt="avatar" width="40" /></a>';
  echo '<a class="boutton" href="deconnexion.php"> Se déconnecter  </a></li>';
}
echo'</div>';
} else{ ?>
<div id="co1">

 <a class="boutton" href="inscription.php">   Inscription  </a></li> 
 <a class="boutton" href="connexion.php">  Se connecter </a></li>
</div>
<?php }?>
<div id="menu">
  <ul id="onglets">
   <li class="active"><a href="Home.php"> Accueil </a></li>
      <li><a href="Group.php"> Rechercher un groupe </a></li>
    <li><a href="creergroupe.php"> Créer un groupe </a></li>
    <li><a href="Forums.php"> Forum</a></li>
    <li><a href="Help.php"> Aide</a></li>
  </ul>
</div>
</header>
<section>
<article style="position:relative; left:35%;
                                 top:20%;
                 width:25%;
    height:35%;
    background-color: #404040;">

<form method ="post" >
<div id="news">

      </br> <legend><h2>&emsp;Connexion administrateur</h2></legend><p>

<label for="nom">&emsp;&nbsp;Nom :</label>&emsp;&emsp;&emsp;&nbsp;&nbsp;
<input type ="text" name="nom" id="nom" placeholder="Nom.." required/>

</br>

<label for="pass">&emsp;&nbsp;Mot de passe :</label>
<input type ="password" name="mot_de_passe" id="mot_de_passe" placeholder="Mot de passe.." required/>
</br>

</br>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;<input type="submit"  value="Envoyer" name=Envoyer />
</br>

</p>
&emsp;&nbsp;<a href="connexion.php ">Se connecter en tant qu'utilisateur</a></br></br>&emsp;&emsp;&emsp;


<?php 
try
{
	$bdd = new PDO('mysql:host=localhost;dbname=le_site_du_sport;charset=utf8', 'root', 'root');
}
catch (Exception $e)
{
        die('Erreur : ' . $e->getMessage());
}
 if(isset($_POST['Envoyer']))
    {
htmlentities($mot_de_passe = $_POST['mot_de_passe']);
htmlentities($nom = $_POST['nom']);
// Hachage du mot de passe
$pass_hache = sha1($_POST['mot_de_passe']);
// Vérification des identifiants
$req = $bdd->prepare('SELECT id,nom,prenom,mail,mot_de_passe FROM administrateur WHERE nom = ? AND mot_de_passe = ?');
$req->execute(array(
     $nom,
     $pass_hache));
	
$resultat = $req->fetch();
     print_r($resultat);
if (!$resultat)
{
    echo 'Mauvais identifiant ou mot de passe !';
	
}
else
{
    session_start();
    $_SESSION['id'] = $resultat['id'];
    
	$_SESSION['nom'] = $resultat['nom'];
	$_SESSION['prenom'] =$resultat['prenom'];
	$_SESSION['mot_de_passe'] = $resultat['mot_de_passe'];
	$_SESSION['mail'] = $resultat['mail'];
	
	
    echo 'Vous êtes connecté !';
	header('Location: admin.php');
}
	}
/*<?php
if (isset(valider){
if (isset($_SESSION['id']) AND isset($_SESSION['pseudo']))
{
     header bd1;
}
	header
}
}*/
?>
</div>
</article>
</section>
<footer>
</br>
<a href="https://www.facebook.com/"> <img  src="0facebook-miniature.jpg" alt="Photo de facebook" title="Facebook"/> </a>
<a href="https://www.twitter.com/"> <img src="Twitter_logo.png" alt="Photo de twitter" title="Twitter"/> </a>
<p>qui sommes-nous ? mention légale  condition d'utilisation</p>

</footer>
       
    </body>
</html>