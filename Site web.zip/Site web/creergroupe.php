  <!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
	<link rel="stylesheet" href="sport.css" />
	<title>Le site du sport</title>
</head>

<body>
<div id="bloc_page">
<header>
                 
                    
                     <img id="logo" src="Images site web/le_site_du_sport2.jpg" alt="Photo de sport" title="Le site du sport"/> 

                     <h1> Le site du sport </h1>
                     
                   <nav>
					 <a href="Home.php"id="Home">Accueil</a>
                     <a href="Directory.php"id="Directory">Répertoire</a>
                     <a href="Group.php"id="Group">Groupe</a>  
                     <a href="Forums.php"id="Forums">Forum</a> 
                     <a href="Help.php" id="Help">Aide</a> 
                 </nav>
             </header>
      <section>

				<img id="life" src="Images site web/Fond/Fond8.jpg" alt="Photo de sport" title="Sport is life"/>
					<article>				
				
				<form method="post"  action="bdgroupe.php"  enctype="multipart/form-data">
				<p>

<label for="pseudo">Pseudo :</label>
<input type ="text" name="pseudo" id="pseudo" placeholder="Pseudo.." required/>

<br/>
<br/>
<br/>

<label for="pass">Mot de passe :</label>
<input type ="password" name="mot_de_passe" id="mot_de_passe" placeholder="Mot de passe.." required/>

<br/>
<br/>


</p>
                     <p>
                     <label> Nom Du Groupe: </label> 
                     <input type="text" name="nomgroupe" id="nomgroupe" placeholder="" size="20" maxlength="50" /> </p>
					 
                     
					 </br>
					 </br>
					
					


					  	
                    
					  
					 Sport :
<input type="radio" name="sport" id="sport" value=football /> <label for="masculin">Football</label>
<input type="radio" name="sport" id="sport" value=basketball /> <label for="feminin">Basketball</label>
<input type="radio" name="sport" id="sport" value=baseball /> <label for="feminin">Baseball</label>
<input type="radio" name="sport" id="sport" value=footballamericain/> <label for="feminin">Football Amercicain</label>
  </br>
					 </br>
					 </br>
					
					 <label for="photo">Photo de Groupe : </label>
                     <input type="hidden" name="MAX_FILE_SIZE" value="1048576" />
                    <input type="file" name="photo" id="photo" />
					
					 
					 </br>
					 
					  <br/>
                
                  <br/>  
<br/>
<label for="description"> Description </label><br/>
<textarea name="description" id="description"></textarea>
<br/>
  <br/>
                
                  <br/>  

                    
                     <p>
                     <label for="pseudo"> Adresse de lieu d'activite: </label> 
                     <input type="text" name="adressegroupe" id="adressegroupe" placeholder="" size="20" maxlength="50" /> </p>
					 
                    
                      </br>
					 </br>
					
                     <p>
                     <label for="pseudo"> Code postale: </label> 
                     <input type="text" name="codepostalgroupe" id="codepostalegroupe" placeholder="" size="20" maxlength="50" /> </p>
					    </br>
					 </br>
					 <input type="submit" value="valider"/>
                    
					</form>
					</article>

<aside>
					<div id="calendrier">
                     <iframe name="InlineFrame1" id="InlineFrame1" style="width:180px;height:220px;" src="http://www.mathieuweb.fr/calendrier/calendrier-des-semaines.php?nb_mois=1&nb_mois_ligne=4&mois=&an=&langue=fr&texte_color=B9CBDD&week_color=DAE9F8&week_end_color=C7DAED&police_color=453413&sel=true" scrolling="no" frameborder="0" allowtransparency="true"></iframe>


                     </br> 

                     <a href="https://www.facebook.com/"> <img id="facebook" src="Images site web/0facebook-miniature.jpg" alt="Photo de facebook" title="Facebook"/> </a>
                     <a href="https://www.twitter.com/"> <img id="twitter"src="Images site web/Twitter_logo.mini.mini.png" alt="Photo de twitter" title="Twitter"/> </a>
                     <a href="https://www.gmail.com/"> <img id="gmail" src="Images site web/images.mini.mini.mini.jpg" alt="Photo de gmail" title="Gmail"/> </a>
                     </div>
                     </aside>
				</section>
				<footer>
                     <a href="Francais.html"> <img id="france" src="Images site web/drapeauF.gif" alt="Drapeau de la France" title="Français"/> </a>
                     <a href="Américain.html"> <img id="amerique" src="Images site web/flagus.mini.mini.mini.gif" alt="Drapeau des Etats Unis" title="Anglais"/> </a>
             </footer>
        </div>
    </body>
</html>