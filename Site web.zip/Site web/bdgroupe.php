


﻿<?php

try
{
	$bdd = new PDO('mysql:host=localhost;dbname=le_site_du_sport;charset=utf8', 'root', 'root');
}
catch (Exception $e)
{
        die('Erreur : ' . $e->getMessage());
}



    




$req = $bdd->prepare('INSERT INTO groupe (nomgroupe,description) VALUES(?,?)');
$req->execute(array(
      
      
	  $_POST['nomgroupe'],
	  $_POST['description']
	  
	
	
	));

	 

	
	
header('Location: creergroupe.php');
?>
	
